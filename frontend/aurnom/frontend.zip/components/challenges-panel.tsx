"use client";

import { PanelExpandButton } from "@/components/panel-expand-button";
import type { ChallengeActive, ChallengesState } from "@/lib/ui-api";
import { useDashboardPanelOpen } from "@/lib/use-dashboard-panel-open";

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

const CADENCE_LABELS: Record<string, string> = {
  daily: "Daily",
  weekly: "Weekly",
  monthly: "Monthly",
  quarter: "Quarterly",
  half_year: "Six-month",
  year: "Yearly",
};

const CADENCE_ORDER: Record<string, number> = {
  daily: 0,
  weekly: 1,
  monthly: 2,
  quarter: 3,
  half_year: 4,
  year: 5,
};

function statusLabel(status: string) {
  switch (status) {
    case "complete":
      return "Complete";
    case "claimed":
      return "Claimed";
    case "in_progress":
      return "In progress";
    case "expired":
      return "Expired";
    default:
      return status;
  }
}

/** Status line color — cyan = done/on-theme, amber = active (matches dashboard warnings). */
function statusToneClass(status: string) {
  switch (status) {
    case "complete":
    case "claimed":
      return "text-cyber-cyan";
    case "in_progress":
      return "text-amber-400";
    case "expired":
      return "text-red-400/85";
    default:
      return "text-ui-muted";
  }
}

function formatWindowKey(key: string, cadence: string) {
  if (!key) return "";
  if (cadence === "daily") {
    try {
      return new Date(key + "T00:00:00Z").toLocaleDateString(undefined, {
        weekday: "short",
        month: "short",
        day: "numeric",
      });
    } catch {
      return key;
    }
  }
  return key;
}

// ---------------------------------------------------------------------------
// Sub-components
// ---------------------------------------------------------------------------

function SummaryLine({ text }: { text: string }) {
  const parts = text.split(/(\[DEV\])/g);
  return (
    <div className="mt-0.5 font-mono text-ui-muted leading-snug">
      {parts.map((part, i) =>
        part === "[DEV]" ? (
          <span key={i} className="text-fuchsia-400/90">
            {part}
          </span>
        ) : (
          <span key={i}>{part}</span>
        ),
      )}
    </div>
  );
}

function ChallengeRow({
  entry,
  onClaim,
  claimBusy,
}: {
  entry: ChallengeActive;
  onClaim?: (challengeId: string, windowKey: string) => void | Promise<void>;
  claimBusy?: boolean;
}) {
  const done = entry.status === "complete" || entry.status === "claimed";
  const canClaim = entry.status === "complete" && onClaim;
  return (
    <div className="border-b border-zinc-800/60 pb-1 last:border-0 last:pb-0">
      <div className="flex min-w-0 items-start gap-1">
        <div className="min-w-0 flex-1">
          <div
            className={`min-w-0 truncate font-mono ${done ? "text-cyber-cyan/85" : "text-foreground"}`}
          >
            {entry.title}
          </div>
          <SummaryLine text={entry.summary} />
        </div>
        <div className="shrink-0 text-right">
          <div
            className={`text-xs font-semibold uppercase tracking-wide ${statusToneClass(entry.status)}`}
          >
            {statusLabel(entry.status)}
          </div>
          <div className="text-xs text-ui-muted">{formatWindowKey(entry.windowKey, entry.cadence)}</div>
          {canClaim ? (
            <button
              type="button"
              disabled={claimBusy}
              onClick={() => void onClaim(entry.challengeId, entry.windowKey)}
              className="mt-0.5 rounded border border-cyan-600/50 bg-cyan-950/60 px-1.5 py-0.5 text-ui-caption font-bold uppercase tracking-wide text-cyber-cyan hover:bg-cyan-900/40 disabled:opacity-40"
            >
              Claim
            </button>
          ) : null}
        </div>
      </div>
    </div>
  );
}

type CadenceGroup = {
  cadence: string;
  entries: ChallengeActive[];
};

function CadenceSection({
  group,
  onClaim,
  onClaimCadence,
  claimBusy,
}: {
  group: CadenceGroup;
  onClaim?: (challengeId: string, windowKey: string) => void | Promise<void>;
  onClaimCadence?: (cadence: string) => void | Promise<void>;
  claimBusy?: boolean;
}) {
  const label = CADENCE_LABELS[group.cadence] ?? group.cadence;
  const completedCount = group.entries.filter(
    (e) => e.status === "complete" || e.status === "claimed",
  ).length;
  const claimableCount = group.entries.filter((e) => e.status === "complete").length;
  const total = group.entries.length;
  const [open, setOpen] = useDashboardPanelOpen(`challenges-cadence:${group.cadence}`, true);

  return (
    <div className="border-t border-cyan-900/25 pt-1.5 first:border-0 first:pt-0">
      <div className="flex min-w-0 flex-wrap items-start gap-x-1 gap-y-1 sm:items-center">
        <span className="min-w-0 flex-1 basis-[min(100%,10rem)] truncate text-xs font-bold uppercase tracking-widest text-cyber-cyan sm:basis-auto">
          {label}
          {completedCount > 0 ? (
            <span className="ml-1 font-mono font-normal normal-case tracking-normal">
              <span className="text-cyber-cyan">{completedCount}</span>
              <span className="text-ui-muted">/</span>
              <span className="text-amber-400">{total}</span>
            </span>
          ) : null}
        </span>
        <div className="ml-auto flex shrink-0 items-center gap-1">
          {claimableCount > 0 && onClaimCadence ? (
            <button
              type="button"
              disabled={claimBusy}
              onClick={() => void onClaimCadence(group.cadence)}
              className="shrink-0 rounded border border-amber-600/50 bg-amber-950/40 px-1.5 py-0.5 text-[10px] font-bold uppercase tracking-wide text-amber-400 hover:bg-amber-900/30 disabled:opacity-40"
            >
              Claim all
            </button>
          ) : null}
          <PanelExpandButton
            open={open}
            onClick={() => setOpen((v) => !v)}
            aria-label={`${open ? "Collapse" : "Expand"} ${label}`}
            className="shrink-0"
          />
        </div>
      </div>
      {open ? (
        <div className="mt-1 space-y-1">
          {group.entries.map((entry) => (
            <ChallengeRow
              key={`${entry.challengeId}-${entry.windowKey}`}
              entry={entry}
              onClaim={onClaim}
              claimBusy={claimBusy}
            />
          ))}
        </div>
      ) : null}
    </div>
  );
}

// ---------------------------------------------------------------------------
// Main panel
// ---------------------------------------------------------------------------

type Props = {
  challenges: ChallengesState;
  onClaimChallenge?: (challengeId: string, windowKey: string) => void | Promise<void>;
  onClaimCadence?: (cadence: string) => void | Promise<void>;
  claimBusy?: boolean;
};

const PANEL_HEADER =
  "flex min-w-0 items-center gap-1 bg-cyan-900/30 px-1.5 py-0.5 text-xs font-bold uppercase tracking-widest";
const PANEL_BODY = "border border-cyan-900/40 bg-zinc-950/80 p-1.5 text-xs";

export function ChallengesPanel({
  challenges,
  onClaimChallenge,
  onClaimCadence,
  claimBusy,
}: Props) {
  const active = challenges.active ?? [];
  const history = challenges.history ?? [];
  const [panelOpen, setPanelOpen] = useDashboardPanelOpen("challenges", true);

  const grouped: CadenceGroup[] = Object.values(
    active.reduce<Record<string, CadenceGroup>>((acc, entry) => {
      const cad = entry.cadence ?? "daily";
      if (!acc[cad]) acc[cad] = { cadence: cad, entries: [] };
      acc[cad].entries.push(entry);
      return acc;
    }, {}),
  ).sort((a, b) => (CADENCE_ORDER[a.cadence] ?? 99) - (CADENCE_ORDER[b.cadence] ?? 99));

  const totalComplete = active.filter(
    (e) => e.status === "complete" || e.status === "claimed",
  ).length;
  const totalActive = active.filter((e) => e.status === "in_progress").length;

  if (active.length === 0 && history.length === 0) {
    return (
      <section className="mb-1">
        <div className={PANEL_HEADER}>
          <span className="min-w-0 truncate text-cyber-cyan">Challenges</span>
        </div>
        <div className={PANEL_BODY}>
          <p className="text-ui-muted">No challenges tracked yet. Explore, trade, or operate a property to begin.</p>
        </div>
      </section>
    );
  }

  return (
    <section className="mb-1">
      <div
        className={`${PANEL_HEADER} max-sm:flex-col max-sm:items-stretch max-sm:gap-y-1 sm:items-center`}
      >
        <div className="flex min-w-0 items-center gap-2">
          <span className="min-w-0 flex-1 truncate text-cyber-cyan">Challenges</span>
          {typeof challenges.pointsLifetime === "number" ? (
            <span className="shrink-0 font-mono text-ui-caption font-normal normal-case tracking-normal text-amber-400/90">
              {challenges.pointsLifetime.toLocaleString()} pts
            </span>
          ) : null}
        </div>
        <div className="flex min-w-0 shrink-0 items-center justify-end gap-1 normal-case tracking-normal sm:ml-auto">
          {totalComplete > 0 || totalActive > 0 ? (
            <span className="min-w-0 truncate text-right font-mono text-ui-caption font-normal">
              {totalComplete > 0 ? (
                <>
                  <span className="text-cyber-cyan">{totalComplete}</span>
                  <span className="text-ui-muted"> ready</span>
                </>
              ) : null}
              {totalComplete > 0 && totalActive > 0 ? <span className="text-ui-muted"> · </span> : null}
              {totalActive > 0 ? (
                <>
                  <span className="text-amber-400">{totalActive}</span>
                  <span className="text-ui-muted"> active</span>
                </>
              ) : null}
            </span>
          ) : null}
          <PanelExpandButton
            open={panelOpen}
            onClick={() => setPanelOpen((v) => !v)}
            aria-label={`${panelOpen ? "Collapse" : "Expand"} Challenges`}
          />
        </div>
      </div>
      {panelOpen ? (
        <div className={PANEL_BODY}>
          <div className="flex flex-col gap-0">
            {grouped.map((group) => (
              <CadenceSection
                key={group.cadence}
                group={group}
                onClaim={onClaimChallenge}
                onClaimCadence={onClaimCadence}
                claimBusy={claimBusy}
              />
            ))}
          </div>

          {history.length > 0 ? (
            <div className="mt-2 border-t border-cyan-900/25 pt-1.5">
              <div className="mb-1 text-xs font-bold uppercase tracking-widest text-cyber-cyan">Recent completions</div>
              <div className="flex flex-col gap-0.5">
                {history.slice(0, 5).map((row) => (
                  <div
                    key={`${row.challengeId}-${row.windowKey}`}
                    className="flex min-w-0 flex-col gap-0.5 border-b border-zinc-800/60 pb-1 last:border-0 last:pb-0 sm:flex-row sm:items-baseline sm:justify-between sm:gap-2 sm:pb-0.5"
                  >
                    <span className="min-w-0 break-words font-mono text-cyber-cyan/90 sm:truncate">
                      {row.title}
                    </span>
                    <span className="shrink-0 self-end font-mono text-xs tabular-nums text-ui-muted sm:self-auto">
                      {row.cadence} · {row.windowKey}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          ) : null}
        </div>
      ) : null}
    </section>
  );
}
