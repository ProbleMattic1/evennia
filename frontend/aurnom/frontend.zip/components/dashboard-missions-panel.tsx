"use client";

import { useRouter } from "next/navigation";
import { useMemo, useState } from "react";

import { groupExits } from "@/components/exit-grid";
import { GameLogPanel } from "@/components/game-log-panel";
import { PanelExpandButton } from "@/components/panel-expand-button";
import type {
  ExitButton,
  MissionActive,
  MissionChoice,
  MissionOpportunity,
  MissionsState,
} from "@/lib/ui-api";
import { acceptMission, chooseMission, declineMission, playInteract, playTravel } from "@/lib/ui-api";
import { useMsgStream } from "@/lib/use-msg-stream";

type Props = {
  missions: MissionsState;
  /** ``_room_exits(char.location)`` from control surface; same facts as the room dialog / play/travel. */
  roomExits?: ExitButton[];
  onChanged: () => void;
};

type ChoiceDialogState = {
  mission: MissionActive;
  choice: MissionChoice;
};

/**
 * Dashboard-styled missions panel with rich interactions (travel/interact/choice)
 * and dialog overlays for accepting opportunities and confirming choices.
 *
 * Intentionally does not reuse `components/mission-board.tsx` since it hardcodes
 * older visual styles (<details>, fuchsia palette, light buttons).
 */
export function DashboardMissionsPanel({ missions, roomExits = [], onChanged }: Props) {
  const router = useRouter();
  const { messages: gameLog } = useMsgStream();

  const opportunities = missions.opportunities ?? [];
  const active = missions.active ?? [];
  const completed = missions.completed ?? [];

  const decisionsPending = useMemo(
    () => active.filter((m) => m.currentObjective?.kind === "choice").length,
    [active],
  );

  const filteredRoomDestinations = useMemo(
    () =>
      roomExits.filter((e): e is ExitButton & { destination: string } => Boolean(e.destination)),
    [roomExits],
  );

  const destinationGroups = useMemo(() => groupExits(filteredRoomDestinations), [filteredRoomDestinations]);

  const storageKey = "aurnom:dashboard-panel:missions";
  const availableStorageKey = "aurnom:dashboard-panel:missions:available";
  const exitsStorageKey = "aurnom:dashboard-panel:missions:exits";
  const [open, setOpen] = useState(() => {
    if (typeof window === "undefined") return true;
    try {
      const raw = window.sessionStorage.getItem(storageKey);
      return raw == null ? true : raw === "1";
    } catch {
      return true;
    }
  });
  const [availableOpen, setAvailableOpen] = useState(() => {
    if (typeof window === "undefined") return true;
    try {
      const raw = window.sessionStorage.getItem(availableStorageKey);
      return raw == null ? true : raw === "1";
    } catch {
      return true;
    }
  });
  const [exitsOpen, setExitsOpen] = useState(() => {
    if (typeof window === "undefined") return true;
    try {
      const raw = window.sessionStorage.getItem(exitsStorageKey);
      return raw == null ? true : raw === "1";
    } catch {
      return true;
    }
  });

  const [busyKey, setBusyKey] = useState<string | null>(null);
  const [flash, setFlash] = useState<string | null>(null);

  const [acceptOpp, setAcceptOpp] = useState<MissionOpportunity | null>(null);
  const [choiceDialog, setChoiceDialog] = useState<ChoiceDialogState | null>(null);
  const [detailMission, setDetailMission] = useState<MissionActive | null>(null);

  function toggleOpen() {
    setOpen((v) => {
      const next = !v;
      try {
        window.sessionStorage.setItem(storageKey, next ? "1" : "0");
      } catch {
        // ignore storage failures
      }
      return next;
    });
  }

  function toggleAvailableOpen() {
    setAvailableOpen((v) => {
      const next = !v;
      try {
        window.sessionStorage.setItem(availableStorageKey, next ? "1" : "0");
      } catch {
        // ignore storage failures
      }
      return next;
    });
  }

  function toggleExitsOpen() {
    setExitsOpen((v) => {
      const next = !v;
      try {
        window.sessionStorage.setItem(exitsStorageKey, next ? "1" : "0");
      } catch {
        // ignore storage failures
      }
      return next;
    });
  }

  async function run(key: string, fn: () => Promise<{ message?: string }>) {
    if (busyKey) return;
    setBusyKey(key);
    setFlash(null);
    try {
      const res = await fn();
      setFlash(res.message ?? "OK");
      onChanged();
    } catch (e) {
      setFlash(e instanceof Error ? e.message : "Action failed");
    } finally {
      setBusyKey(null);
    }
  }

  function labelForInteractionKey(key: string): string {
    if (key.startsWith("askguide")) {
      const topic = key.split(":")[1];
      return `Ask guide (${topic ?? "default"})`;
    }
    if (key === "survey") return "Run survey";
    if (key === "contractboard") return "Procurement board";
    if (key.startsWith("contractboard:")) {
      const part = key.split(":")[1];
      return part ? `Procurement board (${part})` : "Procurement board";
    }
    if (key === "frontier:kiosk") {
      return "Transit kiosk";
    }
    return key;
  }

  async function handleAccept(op: MissionOpportunity) {
    await run(`accept:${op.id}`, async () => acceptMission({ opportunityId: op.id }));
    setAcceptOpp(null);
  }

  async function handleDecline(op: MissionOpportunity) {
    await run(`decline:${op.id}`, async () => declineMission({ opportunityId: op.id }));
  }

  async function handleChoose(m: MissionActive, c: MissionChoice) {
    await run(`choose:${m.id}:${c.id}`, async () => chooseMission({ missionId: m.id, choiceId: c.id }));
    setChoiceDialog(null);
  }

  async function handleTravel(m: MissionActive, roomKey: string) {
    await run(`travel:${m.id}:${roomKey}`, async () => playTravel({ destination: roomKey }));
    router.push("/");
    router.refresh();
  }

  async function handleExitTravel(destination: string) {
    await run(`exit:${destination}`, async () => playTravel({ destination }));
    router.push("/");
    router.refresh();
  }

  async function handleInteract(m: MissionActive, interactionKey: string) {
    await run(`interact:${m.id}:${interactionKey}`, async () => playInteract({ interactionKey }));
    router.refresh();
  }

  return (
    <section className="mb-1">
      <div className="flex min-w-0 items-center gap-1 bg-cyan-900/30 px-1.5 py-0.5 text-xs font-bold uppercase tracking-widest">
        <span className="min-w-0 truncate text-cyber-cyan">Missions</span>
        <div className="ml-auto flex min-w-0 shrink-0 items-center gap-1 normal-case tracking-normal">
          <span className="font-mono text-ui-caption font-normal">
            <span className="text-ui-muted">(</span>
            <span className="text-cyber-cyan">{active.length}</span>
            <span className="text-ui-muted"> active / </span>
            <span className="text-amber-400">{opportunities.length}</span>
            <span className="text-ui-muted"> avail)</span>
            <span className="text-ui-muted"> · </span>
            <span className="text-ui-muted">decisions pending: </span>
            <span className={decisionsPending > 0 ? "text-amber-400" : "text-cyber-cyan"}>{decisionsPending}</span>
          </span>
          <PanelExpandButton
            open={open}
            onClick={toggleOpen}
            aria-label={`${open ? "Collapse" : "Expand"} Missions`}
          />
        </div>
      </div>

      {open ? (
        <div className="border border-cyan-900/40 bg-zinc-950/80 p-1.5 text-xs">
          {flash ? (
            <div className="mb-1 rounded border border-cyan-900/40 bg-zinc-950 px-1.5 py-1 text-xs text-foreground">
              <span className="text-cyber-cyan">»</span> {flash}
              <button type="button" className="ml-2 text-ui-muted hover:text-foreground" onClick={() => setFlash(null)}>
                ×
              </button>
            </div>
          ) : null}

          <div className="mb-1.5">
            <div className="mb-0.5 text-xs uppercase tracking-wide text-ui-muted">Game log</div>
            <GameLogPanel messages={gameLog} compact />
          </div>

          <div className="space-y-1">
            {active.length > 0 ? (
              <div>
                <div className="text-xs uppercase text-ui-muted">Active</div>
                <div className="mt-0.5 space-y-1">
                  {active.map((m) => {
                    const obj = m.currentObjective ?? null;
                    const prompt = obj?.text ?? obj?.prompt ?? null;
                    const isChoice = obj?.kind === "choice" && (obj.choices?.length ?? 0) > 0;

                    return (
                      <div key={m.id} className="border-b border-zinc-800/60 pb-1 last:border-0 last:pb-0">
                        <div className="flex min-w-0 items-baseline gap-2">
                          <button
                            type="button"
                            className="min-w-0 truncate text-left font-semibold text-foreground hover:text-cyber-cyan"
                            onClick={() => setDetailMission(m)}
                          >
                            {m.title}
                          </button>
                          <span className="ml-auto shrink-0 text-ui-caption text-ui-muted">{m.status}</span>
                        </div>

                        {prompt ? <div className="mt-0.5 text-ui-muted">{prompt}</div> : null}

                        {obj?.kind === "visit_room" && (obj.roomKeysAny?.length ?? 0) > 0 ? (
                          <div className="mt-0.5 flex flex-wrap gap-1">
                            {obj.roomKeysAny!.map((roomKey) => {
                              const k = `travel:${m.id}:${roomKey}`;
                              return (
                                <TinyButton key={k} onClick={() => handleTravel(m, roomKey)} disabled={busyKey === k}>
                                  {busyKey === k ? "Traveling…" : `Go: ${roomKey}`}
                                </TinyButton>
                              );
                            })}
                          </div>
                        ) : null}

                        {obj?.kind === "interaction" && (obj.interactionKeysAny?.length ?? 0) > 0 ? (
                          <div className="mt-0.5 flex flex-wrap gap-1">
                            {obj.interactionKeysAny!.map((interactionKey) => {
                              const k = `interact:${m.id}:${interactionKey}`;
                              return (
                                <TinyButton
                                  key={k}
                                  onClick={() => handleInteract(m, interactionKey)}
                                  disabled={busyKey === k}
                                >
                                  {busyKey === k ? "Running…" : labelForInteractionKey(interactionKey)}
                                </TinyButton>
                              );
                            })}
                          </div>
                        ) : null}

                        {isChoice ? (
                          <div className="mt-0.5 flex flex-wrap gap-1">
                            {obj!.choices!.map((c) => (
                              <TinyButton key={`${m.id}:${c.id}`} onClick={() => setChoiceDialog({ mission: m, choice: c })}>
                                {c.label}
                              </TinyButton>
                            ))}
                          </div>
                        ) : null}
                      </div>
                    );
                  })}
                </div>
              </div>
            ) : null}

            {opportunities.length > 0 ? (
              <div>
                <div className="flex items-center text-xs uppercase text-ui-muted">
                  <span>Available</span>
                  <PanelExpandButton
                    open={availableOpen}
                    onClick={toggleAvailableOpen}
                    aria-label={`${availableOpen ? "Collapse" : "Expand"} Available missions`}
                    className="ml-auto shrink-0"
                  />
                </div>
                {availableOpen ? (
                  <div className="mt-0.5 max-h-[min(280px,45vh)] min-h-[48px] space-y-0.5 overflow-y-auto overflow-x-hidden border border-cyan-900/40 bg-zinc-950/80 p-1.5 pr-2 [scrollbar-gutter:stable]">
                    {opportunities.map((op) => (
                      <div key={op.id} className="flex min-w-0 items-baseline gap-2">
                        <button
                          type="button"
                          className="min-w-0 flex-1 truncate text-left text-ui-muted hover:text-cyber-cyan"
                          onClick={() => setAcceptOpp(op)}
                          title={op.summary}
                        >
                          {op.title}
                        </button>
                        <TinyButton variant="pink" onClick={() => setAcceptOpp(op)}>
                          Accept…
                        </TinyButton>
                        <TinyButton
                          variant="cyan"
                          onClick={() => handleDecline(op)}
                          disabled={busyKey === `decline:${op.id}`}
                        >
                          {busyKey === `decline:${op.id}` ? "…" : "X"}
                        </TinyButton>
                      </div>
                    ))}
                  </div>
                ) : null}
              </div>
            ) : null}

            {completed.length > 0 ? (
              <div>
                <div className="text-xs uppercase text-ui-muted">{`Completed (${completed.length})`}</div>
                <div className="mt-0.5 space-y-0.5">
                  {completed.slice(-6).map((m) => (
                    <div key={m.id} className="flex min-w-0 items-baseline gap-2">
                      <span className="min-w-0 flex-1 truncate text-ui-muted">{m.title}</span>
                      {m.completedAt ? (
                        <span className="shrink-0 text-ui-caption text-ui-soft">
                          {new Date(m.completedAt).toLocaleString()}
                        </span>
                      ) : null}
                    </div>
                  ))}
                </div>
              </div>
            ) : null}

            {active.length === 0 && opportunities.length === 0 ? <div className="text-ui-muted">No missions available.</div> : null}
          </div>

          {roomExits.some((e) => e.destination) ? (
            <div className="mt-1.5">
              <div className="mb-0.5 flex items-center text-xs uppercase tracking-wide text-ui-muted">
                <span>Destinations</span>
                <PanelExpandButton
                  open={exitsOpen}
                  onClick={toggleExitsOpen}
                  aria-label={`${exitsOpen ? "Collapse" : "Expand"} Destinations`}
                  className="ml-auto shrink-0"
                />
              </div>
              {exitsOpen ? (
                destinationGroups.length <= 1 &&
                (destinationGroups[0]?.title === "Destinations" || !destinationGroups[0]) ? (
                  <div className="mt-0.5 flex flex-wrap gap-1">
                    {filteredRoomDestinations.map((ex) => {
                      const k = `exit:${ex.destination}`;
                      return (
                        <TinyButton
                          key={`${ex.key}-${ex.destination}`}
                          onClick={() => handleExitTravel(ex.destination)}
                          disabled={busyKey === k}
                        >
                          {busyKey === k ? "Moving…" : ex.label}
                        </TinyButton>
                      );
                    })}
                  </div>
                ) : (
                  <div className="mt-0.5 flex flex-col gap-2">
                    {destinationGroups.map(({ title, items }) => (
                      <div key={title}>
                        <div className="mb-0.5 text-xs uppercase tracking-wide text-ui-muted">
                          {title}
                        </div>
                        <div className="flex flex-wrap gap-1">
                          {items.map((ex) => {
                            const k = `exit:${ex.destination}`;
                            return (
                              <TinyButton
                                key={`${ex.key}-${ex.destination}`}
                                onClick={() => handleExitTravel(ex.destination!)}
                                disabled={busyKey === k}
                              >
                                {busyKey === k ? "Moving…" : ex.label}
                              </TinyButton>
                            );
                          })}
                        </div>
                      </div>
                    ))}
                  </div>
                )
              ) : null}
            </div>
          ) : null}
        </div>
      ) : null}

      {acceptOpp ? (
        <OverlayDialog title="Accept mission" onClose={() => setAcceptOpp(null)}>
          <div className="space-y-1">
            <div className="text-xs font-semibold text-foreground">{acceptOpp.title}</div>
            <div className="text-ui-muted">{acceptOpp.summary}</div>

            <div className="mt-2 flex items-center gap-1">
              <TinyButton
                onClick={() => handleAccept(acceptOpp)}
                disabled={busyKey === `accept:${acceptOpp.id}`}
              >
                {busyKey === `accept:${acceptOpp.id}` ? "Accepting…" : "Confirm accept"}
              </TinyButton>
              <TinyButton onClick={() => setAcceptOpp(null)}>Cancel</TinyButton>
            </div>
          </div>
        </OverlayDialog>
      ) : null}

      {choiceDialog ? (
        <OverlayDialog title="Decide" onClose={() => setChoiceDialog(null)}>
          <div className="space-y-1">
            <div className="text-xs font-semibold text-foreground">{choiceDialog.mission.title}</div>
            <div className="text-ui-muted">
              {choiceDialog.mission.currentObjective?.prompt ?? choiceDialog.mission.currentObjective?.text}
            </div>

            <div className="mt-2 rounded border border-cyan-900/40 bg-zinc-950 p-1.5">
              <div className="text-xs uppercase tracking-wide text-ui-muted">Choice</div>
              <div className="text-foreground">{choiceDialog.choice.label}</div>

              {choiceDialog.choice.outcome ? (
                <div className="mt-1 text-ui-muted">
                  <span className="text-ui-muted">Outcome:</span> {choiceDialog.choice.outcome}
                </div>
              ) : null}

              {choiceDialog.choice.morality ? (
                <div className="mt-1 text-xs text-ui-muted">{formatMoralityDelta(choiceDialog.choice.morality)}</div>
              ) : null}

              {choiceDialog.choice.rewards ? (
                <div className="mt-1 text-xs text-ui-muted">{formatRewards(choiceDialog.choice.rewards)}</div>
              ) : null}
            </div>

            <div className="mt-2 flex items-center gap-1">
              <TinyButton
                onClick={() => handleChoose(choiceDialog.mission, choiceDialog.choice)}
                disabled={busyKey === `choose:${choiceDialog.mission.id}:${choiceDialog.choice.id}`}
              >
                {busyKey === `choose:${choiceDialog.mission.id}:${choiceDialog.choice.id}` ? "Submitting…" : "Confirm"}
              </TinyButton>
              <TinyButton onClick={() => setChoiceDialog(null)}>Cancel</TinyButton>
            </div>
          </div>
        </OverlayDialog>
      ) : null}

      {detailMission ? (
        <OverlayDialog title="Mission detail" onClose={() => setDetailMission(null)}>
          <div className="space-y-1">
            <div className="text-xs font-semibold text-foreground">{detailMission.title}</div>
            {detailMission.summary ? <div className="text-ui-muted">{detailMission.summary}</div> : null}

            {detailMission.choices && detailMission.choices.length > 0 ? (
              <div className="mt-2">
                <div className="text-xs uppercase text-ui-muted">History</div>
                <div className="mt-0.5 space-y-0.5">
                  {detailMission.choices.slice(-6).map((c, idx) => (
                    <div key={`${c.objectiveId}:${c.choiceId}:${idx}`} className="text-xs text-ui-muted">
                      <span className="text-ui-muted">{new Date(c.chosenAt).toLocaleString()}:</span>{" "}
                      {c.outcome || `${c.objectiveId} → ${c.choiceId}`}
                    </div>
                  ))}
                </div>
              </div>
            ) : null}

            <div className="mt-2 flex items-center gap-1">
              <TinyButton onClick={() => setDetailMission(null)}>Close</TinyButton>
            </div>
          </div>
        </OverlayDialog>
      ) : null}
    </section>
  );
}

function TinyButton({
  onClick,
  disabled,
  variant = "cyan",
  children,
}: {
  onClick: () => void;
  disabled?: boolean;
  variant?: "cyan" | "pink";
  children: React.ReactNode;
}) {
  const cls =
    variant === "pink"
      ? "shrink-0 rounded border border-pink-500/80 px-1 py-0 text-xs text-pink-400 hover:bg-pink-950/50 disabled:opacity-40"
      : "shrink-0 rounded border border-cyan-800/60 px-1 py-0 text-xs text-cyber-cyan hover:bg-cyan-900/40 disabled:opacity-40";
  return (
    <button type="button" onClick={onClick} disabled={disabled} className={cls}>
      {children}
    </button>
  );
}

function OverlayDialog({
  title,
  children,
  onClose,
}: {
  title: string;
  children: React.ReactNode;
  onClose: () => void;
}) {
  return (
    <div className="fixed inset-0 z-50" role="dialog" aria-modal="true" aria-label={title}>
      <button type="button" className="absolute inset-0 bg-zinc-950/70" aria-label="Close dialog" onClick={onClose} />
      <div className="absolute left-1/2 top-12 w-[min(520px,94vw)] -translate-x-1/2 rounded border border-cyan-900/60 bg-zinc-950 p-2 text-xs text-foreground shadow-xl">
        <div className="mb-1 flex items-center gap-2 border-b border-zinc-800/60 pb-1">
          <div className="text-xs font-bold uppercase tracking-widest text-cyber-cyan">{title}</div>
          <button type="button" className="ml-auto text-ui-muted hover:text-foreground" onClick={onClose}>
            ×
          </button>
        </div>
        {children}
      </div>
    </div>
  );
}

function formatMoralityDelta(delta: Record<string, unknown>) {
  const parts: string[] = [];
  for (const k of ["good", "evil", "lawful", "chaotic"] as const) {
    const v = Number(delta[k] ?? 0);
    if (!v) continue;
    parts.push(`${k} ${v > 0 ? `+${v}` : String(v)}`);
  }
  return parts.length ? `Morality: ${parts.join(" · ")}` : "";
}

function formatRewards(rewards: Record<string, unknown>) {
  const parts: string[] = [];
  for (const [k, v] of Object.entries(rewards)) {
    if (v == null) continue;
    parts.push(`${k}: ${String(v)}`);
  }
  return parts.length ? `Rewards: ${parts.join(" · ")}` : "";
}
