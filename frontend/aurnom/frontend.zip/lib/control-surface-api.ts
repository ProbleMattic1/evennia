/**
 * TypeScript contract for the /ui/control-surface aggregated read model.
 *
 * All types mirror the Python serializers in game/web/ui/control_surface.py.
 * Import action helpers (accept/choose missions, ack alerts, etc.) directly
 * from ui-api.ts — they share the same POST endpoints.
 */

import type {
  CarriedInventoryPayload,
  ChallengesState,
  DashboardAlert,
  DashboardGroupedAlerts,
  DashboardMine,
  DashboardProperty,
  DashboardShip,
  ExitButton,
  MarketCommodity,
  MissionsState,
  OreReceivingBayRow,
  ProcessingHaulerMode,
} from "./ui-api";

import { UI_PREFIX } from "./ui-endpoints";
import type { ClientPollHints } from "./ui-refresh-policy";

// ---------------------------------------------------------------------------
// Nav
// ---------------------------------------------------------------------------

export type NavKiosk = {
  key: string;
  label: string;
  href: string;
};

export type NavShop = {
  roomKey: string;
  label: string;
};

export type NavMineLink = {
  key: string;
  label: string;
  href: string;
  active: boolean;
  kind?: string | null;
};

export type NavClaimLink = {
  label: string;
  href: string;
  volumeTier?: string;
  volumeTierCls?: string;
  resourceRarityTier?: string;
  resourceRarityTierCls?: string;
  /** Bid-valued est. production per cycle (cr), same formula as claim detail. */
  estimatedValuePerCycle?: number;
};

export type NavPropertyLink = {
  label: string;
  href: string;
};

export type NavExit = {
  key: string;
  label: string;
  command: string;
  destination: string | null;
};

export type ControlSurfaceNav = {
  hubRoomKey: string;
  exits: NavExit[];
  kiosks: NavKiosk[];
  shops: NavShop[];
  claims: NavClaimLink[];
  properties: NavPropertyLink[];
  resources: NavMineLink[];
  /** Deprecated mirror of ``resources``; same entries. */
  mines: NavMineLink[];
};

// ---------------------------------------------------------------------------
// Character block
// ---------------------------------------------------------------------------

export type CsAbility = {
  name: string;
  score: number;
  base: number;
  mod: number;
  abilityMod: number;
};

export type CsVitalGauge = {
  name: string;
  current: number;
  max: number | null;
};

export type CsCharacter = {
  id: number;
  key: string;
  room: string | null;
  roomId: number | null;
  credits: number;
  abilities: Record<string, CsAbility>;
  vitals: { hp?: CsVitalGauge };
  armorClass: number;
  /** RPG level; present when server sends progression snapshot. */
  level?: number;
  xpIntoLevel?: number;
  xpToNext?: number;
};

// ---------------------------------------------------------------------------
// Inventory
// ---------------------------------------------------------------------------

export type CsInventory = CarriedInventoryPayload;

// ---------------------------------------------------------------------------
// Processing summary
// ---------------------------------------------------------------------------

/** One row in merged plant silo + local raw reserve. */
export type PersonalStorageEntry = {
  tons: number;
  /** Bid-priced credits at each stash location, summed if split across silo + local. */
  estimatedValueCr: number;
};

/** Merged plant silo + local raw reserve, by resource key. */
export type PersonalStorageBuckets = {
  mine: Record<string, PersonalStorageEntry>;
  flora: Record<string, PersonalStorageEntry>;
  fauna: Record<string, PersonalStorageEntry>;
};

export type CsProcessing = {
  plantName: string;
  oreReceivingBay: OreReceivingBayRow[];
  rawStorageUsed: number;
  rawStorageCapacity: number;
  refineryInputTons: number;
  refineryOutputValue: number;
  minerQueueOreTons: number;
  minerOutputValueTotal: number;
  processingFeeRate: number;
  rawSaleFeeRate: number;
  rawAskPremiumRate: number;
  myOreQueued: number | null;
  myRefinedOutput: Record<string, number> | null;
  myRefinedOutputValue: number | null;
  myHaulers: ProcessingHaulerMode[] | null;
};

// ---------------------------------------------------------------------------
// Root state
// ---------------------------------------------------------------------------

export type PlayableCharacterRow = {
  id: number;
  key: string;
};

/** Cached on ``economy_world_telemetry``; sum of per-character pipeline estimates. */
export type WorldProductionPipelineSnapshot = {
  playerCharacterCount?: number;
  estimatedPipelineTotalCr?: number;
  storedSitesBidCr?: number;
  accrualThisSlotEstimatedCr?: number;
  /** Σ per-character implied accrual (cycle caps ÷ delivery periods), as cr/hour; not UTC slot progress. */
  impliedAccrualCrPerHourTotal?: number;
  note?: string;
};

export type ControlSurfaceState = {
  schemaVersion: number;
  /** Optional server-suggested poll intervals (ms); same keys as `UI_REFRESH_MS`. */
  clientPollHints?: ClientPollHints;
  authenticated: boolean;
  character: CsCharacter | null;
  /** Populated when logged in but no active character resolved (e.g. multi-character pick). */
  playableCharacters?: PlayableCharacterRow[];
  credits: number | null;
  inventory: CsInventory;
  ships: DashboardShip[];
  resources: DashboardMine[];
  /** Deprecated mirror of ``resources``; same rows. */
  mines: DashboardMine[];
  /** Next UTC-aligned mining delivery instant (shared grid); ISO string. */
  miningNextCycleAt?: string;
  /** Seconds; matches ``world.time.MINING_DELIVERY_PERIOD``. */
  miningDeliveryPeriodSeconds?: number;
  /** Seconds; matches ``world.time.FLORA_DELIVERY_PERIOD``. */
  floraDeliveryPeriodSeconds?: number;
  /** Server UTC instant when this payload was built (ISO). */
  serverTimeIso?: string;
  /** Start of current UTC mining delivery slot (ISO). */
  miningSlotStartIso?: string;
  /** Start of current UTC flora delivery slot (ISO). */
  floraSlotStartIso?: string;
  /** Next UTC-aligned flora delivery instant (ISO). */
  floraNextCycleAt?: string;
  /** Sum of accrualValuePerCycle for mining sites only. */
  miningAccrualValuePerCycle?: number;
  /** Sum of accrualValuePerCycle for flora sites only. */
  floraAccrualValuePerCycle?: number;
  /** Sum of accrualValuePerCycle for fauna sites only. */
  faunaAccrualValuePerCycle?: number;
  productionEstimatedValuePerCycle: number;
  productionTotalStoredValue: number;
  miningEstimatedValuePerCycle: number;
  miningTotalStoredValue: number;
  /** Plant-assigned personal ore silo (processing plant), bid value in cr. */
  miningPersonalStoredValue: number;
  /** Local raw reserve (e.g. Killstar annex tagged storage), bid value in cr. */
  miningLocalRawStoredValue: number;
  /** Merged plant silo + local raw reserve; tons + bid-valued credits per key. */
  personalStorage?: PersonalStorageBuckets;
  properties: DashboardProperty[];
  propertyReferenceListValueTotalCr: number;
  processing: CsProcessing | null;
  market: MarketCommodity[];
  alerts: DashboardAlert[];
  groupedAlerts: DashboardGroupedAlerts;
  missions: MissionsState;
  challenges?: ChallengesState;
  nav: ControlSurfaceNav;
  /** Same list as ``views._room_exits(char.location)``; matches room dialog / ``play/travel`` resolution. */
  roomExits: ExitButton[];
  treasuryBalance: number | null;
  message: string | null;
  /** Credits paid to miners in the last completed mining delivery slot (UTC grid). */
  minerPayoutLastCycleCr: number;
  /** All-time credits paid from treasury to miners (plant raw + refined collect). */
  minerPayoutTotalCr: number;
  /** Gross face value (cr), last completed mining slot — since counters added. */
  minerSettlementLastCycleGrossCr?: number;
  /** Fees retained (cr), last completed mining slot — since counters added. */
  minerSettlementLastCycleFeesCr?: number;
  /** All-time gross settlement face value (cr) — since counters added. */
  minerSettlementTotalGrossCr?: number;
  /** All-time fees retained (cr) — since counters added. */
  minerSettlementTotalFeesCr?: number;
  /** Net credits to miners this in-progress mining UTC slot. */
  minerSettlementThisSlotNetCr?: number;
  /** Gross settlement face value (cr) this slot. */
  minerSettlementThisSlotGrossCr?: number;
  /** Fees retained (cr) this slot. */
  minerSettlementThisSlotFeesCr?: number;
  /** World roll-up from telemetry script (not recomputed per GET). */
  worldProductionPipeline?: WorldProductionPipelineSnapshot | null;
};

// ---------------------------------------------------------------------------
// Fetcher
// ---------------------------------------------------------------------------

async function _readJson<T>(res: Response): Promise<T> {
  const text = await res.text();
  try {
    return JSON.parse(text) as T;
  } catch {
    throw new Error(text || res.statusText || "Invalid JSON");
  }
}

export async function getControlSurfaceState(): Promise<ControlSurfaceState> {
  const res = await fetch(`${UI_PREFIX}/control-surface`, {
    credentials: "include",
    cache: "no-store",
  });
  if (!res.ok) {
    let message: string | undefined;
    try {
      const body = await _readJson<{ message?: string }>(res);
      message = body.message;
    } catch {
      message = undefined;
    }
    throw new Error(message ?? `Request failed (${res.status})`);
  }
  return _readJson<ControlSurfaceState>(res);
}

export async function setWebActiveCharacter(characterId: number): Promise<void> {
  const res = await fetch(`${UI_PREFIX}/active-character`, {
    method: "POST",
    credentials: "include",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ characterId }),
    cache: "no-store",
  });
  const text = await res.text();
  let parsed: { message?: string; ok?: boolean } | null = null;
  try {
    parsed = JSON.parse(text) as { message?: string; ok?: boolean };
  } catch {
    parsed = null;
  }
  if (!res.ok || parsed?.ok === false) {
    throw new Error((parsed?.message ?? text) || `Request failed (${res.status})`);
  }
}

export async function clearWebActiveCharacter(): Promise<void> {
  const res = await fetch(`${UI_PREFIX}/active-character/clear`, {
    method: "POST",
    credentials: "include",
    cache: "no-store",
  });

  const text = await res.text();
  let parsed: { message?: string; ok?: boolean } | null = null;
  try {
    parsed = JSON.parse(text) as { message?: string; ok?: boolean };
  } catch {
    parsed = null;
  }

  if (!res.ok || parsed?.ok === false) {
    throw new Error((parsed?.message ?? text) || `Request failed (${res.status})`);
  }
}
