import type { ControlSurfaceState } from "@/lib/control-surface-api";
import type { DashboardMine } from "@/lib/ui-api";

const FALLBACK_PERIOD_SEC = 1800;

export function miningPeriodSeconds(data: ControlSurfaceState | null): number {
  const n = data?.miningDeliveryPeriodSeconds;
  return typeof n === "number" && n > 0 ? n : FALLBACK_PERIOD_SEC;
}

/** Implied CR/s if the current cycle expectation repeats at current bids. */
export function impliedPortfolioCrPerSec(data: ControlSurfaceState | null): number {
  if (!data?.authenticated) return 0;
  const period = miningPeriodSeconds(data);
  const v = data.productionEstimatedValuePerCycle ?? data.miningEstimatedValuePerCycle ?? 0;
  return period > 0 ? v / period : 0;
}

/** Sum estimatedOutputTons for active mines → implied t/s. */
export function impliedPortfolioTonsPerSec(data: ControlSurfaceState | null): number {
  if (!data?.authenticated) return 0;
  const sites = data.resources ?? data.mines;
  if (!sites?.length) return 0;
  const period = miningPeriodSeconds(data);
  const tons = sites
    .filter((m) => m.active)
    .reduce((s, m) => s + (m.estimatedOutputTons ?? 0), 0);
  return period > 0 ? tons / period : 0;
}

/** 0..1 progress through current mining delivery slot (UTC grid). */
export function miningCycleProgress(nowMs: number, nextIso: string | undefined, periodSec: number): number {
  if (!nextIso || periodSec <= 0) return 0;
  const next = Date.parse(nextIso);
  if (!Number.isFinite(next)) return 0;
  const start = next - periodSec * 1000;
  const denom = next - start;
  if (denom <= 0) return 0;
  const t = (nowMs - start) / denom;
  return Math.min(1, Math.max(0, t));
}

export type CompositionRow = { key: string; tons: number };

/** Active mines: estimated output × composition fractions. */
export function aggregateEstimatedComposition(mines: DashboardMine[]): CompositionRow[] {
  const m = new Map<string, number>();
  for (const mine of mines) {
    if (!mine.active) continue;
    const tons = mine.estimatedOutputTons ?? 0;
    const comp = mine.composition || {};
    for (const [k, frac] of Object.entries(comp)) {
      m.set(k, (m.get(k) ?? 0) + tons * Number(frac));
    }
  }
  return [...m.entries()]
    .map(([key, t]) => ({ key, tons: t }))
    .filter((r) => r.tons > 0)
    .sort((a, b) => b.tons - a.tons);
}

export function formatCrPerSec(n: number): string {
  if (n >= 1) return `${n.toFixed(2)}cr/s`;
  return `${(n * 100).toFixed(1)} ¢/s`;
}

/** 0..1 through slot [slotStartIso, slotStartIso + periodSec]. */
export function deliverySlotProgress(
  nowMs: number,
  slotStartIso: string | undefined,
  periodSec: number,
): number {
  if (!slotStartIso || periodSec <= 0) return 0;
  const start = Date.parse(slotStartIso);
  if (!Number.isFinite(start)) return 0;
  const end = start + periodSec * 1000;
  const denom = end - start;
  if (denom <= 0) return 0;
  return Math.min(1, Math.max(0, (nowMs - start) / denom));
}

/** Linear projected CR accrued this slot (portfolio mining grid). */
export function miningPortfolioAccruedCr(data: ControlSurfaceState, nowMs: number): number {
  const period = miningPeriodSeconds(data);
  const cap =
    data.miningAccrualValuePerCycle ??
    data.productionEstimatedValuePerCycle ??
    data.miningEstimatedValuePerCycle ??
    0;
  const start = data.miningSlotStartIso;
  const p = start
    ? deliverySlotProgress(nowMs, start, period)
    : miningCycleProgress(nowMs, data.miningNextCycleAt, period);
  return Math.floor(p * cap);
}

export function floraPortfolioAccruedCr(data: ControlSurfaceState, nowMs: number): number {
  const period = data.floraDeliveryPeriodSeconds ?? 3600;
  const cap = data.floraAccrualValuePerCycle ?? 0;
  if (!cap) return 0;
  const p = deliverySlotProgress(nowMs, data.floraSlotStartIso, period);
  return Math.floor(p * cap);
}

/** Same UTC grid as flora (shared FLORA_DELIVERY_PERIOD on server). */
export function faunaPortfolioAccruedCr(data: ControlSurfaceState, nowMs: number): number {
  const period = data.floraDeliveryPeriodSeconds ?? 3600;
  const cap = data.faunaAccrualValuePerCycle ?? 0;
  if (!cap) return 0;
  const p = deliverySlotProgress(nowMs, data.floraSlotStartIso, period);
  return Math.floor(p * cap);
}

/** Sum of mining + flora + fauna in-slot accrual estimates (linear 0→cap within each UTC slot). */
export function portfolioAccrualThisSlotTotalCr(data: ControlSurfaceState, nowMs: number): number {
  return (
    miningPortfolioAccruedCr(data, nowMs) +
    floraPortfolioAccruedCr(data, nowMs) +
    faunaPortfolioAccruedCr(data, nowMs)
  );
}

/**
 * Implied portfolio accrual rate in cr/hour from current cycle caps and delivery periods.
 * Continuous-time estimate (not “within this UTC slot” progress).
 */
export function portfolioImpliedAccrualCrPerHour(data: ControlSurfaceState): number {
  const miningSec = miningPeriodSeconds(data);
  const floraSec = data.floraDeliveryPeriodSeconds ?? 3600;
  const m = data.miningAccrualValuePerCycle ?? 0;
  const f = data.floraAccrualValuePerCycle ?? 0;
  const fa = data.faunaAccrualValuePerCycle ?? 0;
  let perSec = 0;
  if (miningSec > 0) perSec += m / miningSec;
  if (floraSec > 0) perSec += (f + fa) / floraSec;
  return Math.floor(Math.max(0, perSec) * 3600);
}

/** Bid-valued storage + linear in-slot mining accrual (estimate, not wallet). */
export function estimatedPipelineTotalCr(data: ControlSurfaceState, nowMs: number): number {
  const stored = data.productionTotalStoredValue ?? data.miningTotalStoredValue ?? 0;
  return stored + portfolioAccrualThisSlotTotalCr(data, nowMs);
}

// ---------------------------------------------------------------------------
// Ore tons (client-side sums from control-surface resources + processing)
// ---------------------------------------------------------------------------

export type PortfolioOreTonsBreakdown = {
  totalTons: number;
  miningSiteTons: number;
  floraSiteTons: number;
  faunaSiteTons: number;
};

function _sitesList(data: ControlSurfaceState | null): DashboardMine[] {
  return data?.resources ?? data?.mines ?? [];
}

/** Sum storageUsed at owned production sites; split by siteKind. */
export function portfolioStoredOreTonsBreakdown(data: ControlSurfaceState | null): PortfolioOreTonsBreakdown {
  let miningSiteTons = 0;
  let floraSiteTons = 0;
  let faunaSiteTons = 0;
  for (const m of _sitesList(data)) {
    const t = Number(m.storageUsed) || 0;
    if (m.siteKind === "flora") floraSiteTons += t;
    else if (m.siteKind === "fauna") faunaSiteTons += t;
    else miningSiteTons += t;
  }
  return {
    totalTons: miningSiteTons + floraSiteTons + faunaSiteTons,
    miningSiteTons,
    floraSiteTons,
    faunaSiteTons,
  };
}

export type PlantOrePoolsDisplay = {
  plantName: string;
  rawBayTons: number;
  refineryInputTons: number;
  myOreQueuedTons: number | null;
  minerQueueOreTons: number;
};

/** Separate pools; do not sum into one “total plant ore” without labeling. */
export function plantOrePoolsDisplay(data: ControlSurfaceState | null): PlantOrePoolsDisplay | null {
  const p = data?.processing;
  if (!p) return null;
  return {
    plantName: p.plantName ?? "Plant",
    rawBayTons: p.rawStorageUsed ?? 0,
    refineryInputTons: p.refineryInputTons ?? 0,
    myOreQueuedTons: p.myOreQueued,
    minerQueueOreTons: p.minerQueueOreTons ?? 0,
  };
}

/** Seconds since start of current mining UTC slot (min 1 to avoid divide-by-zero). */
export function treasuryMiningSlotElapsedSec(data: ControlSurfaceState | null, nowMs: number): number {
  const startIso = data?.miningSlotStartIso;
  if (!startIso) return 1;
  const start = Date.parse(startIso);
  if (!Number.isFinite(start)) return 1;
  return Math.max(1, (nowMs - start) / 1000);
}
