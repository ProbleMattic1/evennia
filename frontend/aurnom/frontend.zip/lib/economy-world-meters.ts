import type { EconomyWorldMeter } from "@/lib/ui-api";

export function linearAccruingValue(m: EconomyWorldMeter, nowMs: number): number {
  const t0 = Date.parse(m.startAtIso);
  const t1 = Date.parse(m.endAtIso);
  if (!Number.isFinite(t0) || !Number.isFinite(t1) || t1 <= t0) {
    return m.valueAtEnd;
  }
  const u = (nowMs - t0) / (t1 - t0);
  const clamped = Math.min(1, Math.max(0, u));
  return m.valueAtStart + (m.valueAtEnd - m.valueAtStart) * clamped;
}
