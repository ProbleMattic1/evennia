/**
 * Subsection layout inside CsPanel (Property Market, Claims Market).
 * Avoids a second bordered “card” — the panel chrome already provides the frame.
 */

export const exchangePanelToolbarClass =
  "mb-2 flex flex-col gap-1.5 sm:flex-row sm:items-baseline sm:justify-between";

export const exchangePanelToolbarTitleClass =
  "min-w-0 text-xs font-bold uppercase tracking-widest text-ui-muted";

export const exchangePanelCountdownClass = "shrink-0 text-xs text-ui-muted";

export const exchangePanelEmptyClass = "py-2 text-sm text-ui-muted";

export const exchangePanelFooterClass =
  "mt-3 border-t border-cyan-900/40 pt-2 text-xs leading-snug text-ui-muted";

/** Matches deed resale / control-surface TinyButton-style actions inside panels. */
export const panelPrimaryButtonClass =
  "rounded border border-cyan-800/60 bg-zinc-900 px-2.5 py-1 text-xs font-semibold text-cyber-cyan hover:bg-cyan-900/40 disabled:cursor-not-allowed disabled:opacity-50";

export const panelInlineLinkClass =
  "rounded border border-cyan-800/60 px-1 py-0 text-xs text-cyber-cyan hover:bg-cyan-900/40";
