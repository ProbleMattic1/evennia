/**
 * Credits and mass display: no space before the cr or t suffix (e.g. 318,760cr, 182.24t).
 */
export function formatCr(n: number | null | undefined, locale?: string): string {
  if (n == null || (typeof n === "number" && Number.isNaN(n))) return "—";
  const s = locale != null ? n.toLocaleString(locale) : n.toLocaleString();
  return `${s}cr`;
}
