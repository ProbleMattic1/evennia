/**
 * Persistent “running meter” for implied accrual (est.): within each UTC day the
 * value grows with wall time at the current implied cr/h rate; at UTC midnight the
 * previous day is closed at 24× that day’s last seen rate and added to carry so the
 * odometer does not snap to zero.
 */

const STORAGE_KEY = "aurnom.impliedAccrualRunning.v1";

export type ImpliedAccrualRunningLedger = {
  utcDay: string;
  carryYou: number;
  carryWorld: number;
  lastYouRate: number;
  lastWorldRate: number;
};

const emptyLedger = (): ImpliedAccrualRunningLedger => ({
  utcDay: "",
  carryYou: 0,
  carryWorld: 0,
  lastYouRate: 0,
  lastWorldRate: 0,
});

export function utcDayKeyFromMs(nowMs: number): string {
  const d = new Date(nowMs);
  if (!Number.isFinite(d.getTime())) return "";
  const y = d.getUTCFullYear();
  const m = String(d.getUTCMonth() + 1).padStart(2, "0");
  const day = String(d.getUTCDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

export function utcMsIntoCurrentDay(nowMs: number): number {
  const d = new Date(nowMs);
  if (!Number.isFinite(d.getTime())) return 0;
  const start = Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate());
  const x = nowMs - start;
  return Math.max(0, Math.min(86400000, x));
}

function loadLedger(): ImpliedAccrualRunningLedger {
  if (typeof window === "undefined") return emptyLedger();
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return emptyLedger();
    const p = JSON.parse(raw) as Partial<ImpliedAccrualRunningLedger>;
    return {
      utcDay: typeof p.utcDay === "string" ? p.utcDay : "",
      carryYou: Number.isFinite(p.carryYou) ? Math.max(0, Math.floor(p.carryYou!)) : 0,
      carryWorld: Number.isFinite(p.carryWorld) ? Math.max(0, Math.floor(p.carryWorld!)) : 0,
      lastYouRate: Number.isFinite(p.lastYouRate) ? Math.max(0, p.lastYouRate!) : 0,
      lastWorldRate: Number.isFinite(p.lastWorldRate) ? Math.max(0, p.lastWorldRate!) : 0,
    };
  } catch {
    return emptyLedger();
  }
}

function saveLedger(b: ImpliedAccrualRunningLedger) {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(b));
  } catch {
    /* quota / private mode */
  }
}

/** Single mutable ledger for the tab; reconciles UTC day rollover during render. */
export function reconcileImpliedRunningLedger(
  ledger: ImpliedAccrualRunningLedger,
  nowMs: number,
  youRate: number,
  worldRate: number,
): { youTarget: number; worldTarget: number } {
  const day = utcDayKeyFromMs(nowMs);
  const yr = Math.max(0, Math.floor(youRate));
  const wr = Math.max(0, Math.floor(worldRate));

  if (!ledger.utcDay) {
    ledger.utcDay = day;
    ledger.lastYouRate = yr;
    ledger.lastWorldRate = wr;
    saveLedger(ledger);
  } else if (ledger.utcDay !== day) {
    ledger.carryYou += Math.floor(ledger.lastYouRate * 24);
    ledger.carryWorld += Math.floor(ledger.lastWorldRate * 24);
    ledger.utcDay = day;
    ledger.lastYouRate = yr;
    ledger.lastWorldRate = wr;
    saveLedger(ledger);
  } else {
    ledger.lastYouRate = yr;
    ledger.lastWorldRate = wr;
  }

  const ms = utcMsIntoCurrentDay(nowMs);
  const youTarget = ledger.carryYou + Math.floor((yr * ms) / 3600000);
  const worldTarget = ledger.carryWorld + Math.floor((wr * ms) / 3600000);
  return { youTarget, worldTarget };
}

let _memoryLedger: ImpliedAccrualRunningLedger | null = null;

export function getRunningLedger(): ImpliedAccrualRunningLedger {
  if (!_memoryLedger) {
    _memoryLedger = loadLedger();
  }
  return _memoryLedger;
}
