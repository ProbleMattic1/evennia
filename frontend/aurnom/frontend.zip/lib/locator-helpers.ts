import type { WorldGraphEdge, WorldGraphRoom } from "@/lib/ui-api";

/** Directed BFS hop count from current room along visible edges; missing = unreachable. */
export function hopDistancesFromCurrent(
  rooms: WorldGraphRoom[],
  edges: WorldGraphEdge[],
  currentRoomKey: string | null,
): Map<number, number> {
  const idByKey = new Map(rooms.map((r) => [r.key, r.id] as const));
  const curId = currentRoomKey ? idByKey.get(currentRoomKey) : undefined;
  const out = new Map<number, number>();
  if (curId === undefined) return out;

  const byFrom = new Map<number, number[]>();
  for (const e of edges) {
    const list = byFrom.get(e.fromId);
    if (list) list.push(e.toId);
    else byFrom.set(e.fromId, [e.toId]);
  }

  out.set(curId, 0);
  const queue = [curId];
  while (queue.length) {
    const n = queue.shift()!;
    const d = out.get(n)!;
    for (const t of byFrom.get(n) ?? []) {
      if (!out.has(t)) {
        out.set(t, d + 1);
        queue.push(t);
      }
    }
  }
  return out;
}

export type OutboundExit = { exitKey: string; toKey: string };

/** Pad / staging exits that share a destination prefix collapse into one row in the list view. */
/**
 * Pad destination keys from bootstrap_npc_industrial_miners, bootstrap_npc_nanomega_industrial_miners,
 * bootstrap_npc_resource_colony_bio, bootstrap_marcus_mines / _flora / _fauna (game/world/*.py).
 */
export const DESTINATION_CLUSTER_PREFIXES: readonly { prefix: string; label: string }[] = [
  { prefix: "Industrial Resource Colony Flora Pad ", label: "Industrial colony flora pads" },
  { prefix: "Industrial Resource Colony Fauna Pad ", label: "Industrial colony fauna pads" },
  { prefix: "Industrial Resource Colony Pad ", label: "Industrial resource colony pads" },
  { prefix: "Ashfall Industrial Pad ", label: "Ashfall industrial pads" },
  { prefix: "NanoMegaPlex Resource Colony Flora Pad ", label: "Plex resource colony flora pads" },
  { prefix: "NanoMegaPlex Resource Colony Fauna Pad ", label: "Plex resource colony fauna pads" },
  { prefix: "NanoMegaPlex Industrial Pad ", label: "Plex industrial pads" },
  { prefix: "Frontier Resource Colony Flora Pad ", label: "Frontier resource colony flora pads" },
  { prefix: "Frontier Resource Colony Fauna Pad ", label: "Frontier resource colony fauna pads" },
  { prefix: "Frontier Industrial Pad ", label: "Frontier industrial pads" },
  { prefix: "Marcus Killstar Flora Pad ", label: "Killstar flora pads" },
  { prefix: "Marcus Killstar Fauna Pad ", label: "Killstar fauna pads" },
  { prefix: "Marcus Killstar Pad ", label: "Killstar mining pads" },
] as const;

/** Room keys for leased industrial pad bays (many per grid — hidden from list by default). */
export function isIndustrialPadRoomKey(key: string): boolean {
  return DESTINATION_CLUSTER_PREFIXES.some(({ prefix }) => key.startsWith(prefix));
}

function padClusterPrefixForDestination(toKey: string): string | null {
  for (const { prefix } of DESTINATION_CLUSTER_PREFIXES) {
    if (toKey.startsWith(prefix)) return prefix;
  }
  return null;
}

export type OutboundExitCluster = { label: string; count: number; exits: OutboundExit[] };

export type OutboundExitDisplayPiece =
  | { kind: "single"; ex: OutboundExit }
  | { kind: "cluster"; cluster: OutboundExitCluster };

/**
 * Group homogenous pad exits into clusters; everything else stays single lines.
 * Pieces are ordered: non-pad singles first (by exit key), then pad singletons, then clusters (by label).
 */
export function outboundExitDisplayPieces(exits: OutboundExit[]): OutboundExitDisplayPiece[] {
  const byPrefix = new Map<string, OutboundExit[]>();
  const nonPad: OutboundExit[] = [];

  for (const ex of exits) {
    const p = padClusterPrefixForDestination(ex.toKey);
    if (p) {
      const list = byPrefix.get(p);
      if (list) list.push(ex);
      else byPrefix.set(p, [ex]);
    } else {
      nonPad.push(ex);
    }
  }

  nonPad.sort((a, b) => a.exitKey.localeCompare(b.exitKey));

  const pieces: OutboundExitDisplayPiece[] = [];
  for (const ex of nonPad) {
    pieces.push({ kind: "single", ex });
  }

  const clusterPieces: OutboundExitDisplayPiece[] = [];
  for (const { prefix, label } of DESTINATION_CLUSTER_PREFIXES) {
    const group = byPrefix.get(prefix);
    if (!group?.length) continue;
    group.sort((a, b) => a.exitKey.localeCompare(b.exitKey));
    if (group.length >= 2) {
      clusterPieces.push({ kind: "cluster", cluster: { label, count: group.length, exits: group } });
    } else {
      pieces.push({ kind: "single", ex: group[0] });
    }
  }
  clusterPieces.sort((a, b) => {
    if (a.kind !== "cluster" || b.kind !== "cluster") return 0;
    return a.cluster.label.localeCompare(b.cluster.label);
  });
  pieces.push(...clusterPieces);
  return pieces;
}

/** Outbound exits per room key (from visible edges). */
export function outboundExitsByRoomKey(edges: WorldGraphEdge[]): Map<string, OutboundExit[]> {
  const m = new Map<string, OutboundExit[]>();
  for (const e of edges) {
    const row: OutboundExit = { exitKey: e.exitKey, toKey: e.toKey };
    const list = m.get(e.fromKey);
    if (list) list.push(row);
    else m.set(e.fromKey, [row]);
  }
  for (const list of m.values()) {
    list.sort((a, b) => a.exitKey.localeCompare(b.exitKey));
  }
  return m;
}
