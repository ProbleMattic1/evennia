import {
  assignZoneId,
  isMegaplexInteriorZone,
  type LocatorZoneId,
  ZONE_ORDER,
} from "@/lib/locator-zones";
import type { LocatorParcelRow, WorldGraphRoom, WorldGraphVenueRow } from "@/lib/ui-api";

const NONE_VENUE = "__none__";

function zoneForRoom(r: WorldGraphRoom): LocatorZoneId {
  return assignZoneId(r.key, r.hasMiningSite, r.locatorZone);
}

function venueKey(r: WorldGraphRoom): string {
  const v = r.venueId;
  if (v === null || v === undefined || v === "") return NONE_VENUE;
  return String(v);
}

/** Relative footprint: hub & concourses >> industrial pads >> field sites. */
export function treemapFootprintForRoom(
  roomKey: string,
  zoneId: LocatorZoneId,
  hasMiningSite: boolean,
): number {
  if (zoneId === "core-hub") return 100;
  if (zoneId === "core-retail") return 17;
  if (zoneId === "core-services") {
    return roomKey.includes("Reserve") ? 42 : 46;
  }
  if (zoneId === "realty-property") return 19;
  if (zoneId === "meridian-shipping") return 24;
  if (zoneId === "nanomega-agency") return 20;
  if (zoneId === "arrival") return 36;
  if (zoneId === "industrial-colony") {
    return roomKey === "Industrial Resource Colony Grid" || roomKey === "Ashfall Industrial Grid"
      ? 24
      : 5;
  }
  if (zoneId === "plex-industrial") {
    if (
      roomKey.includes("Industrial Subdeck") ||
      roomKey.includes("Resource Colony Flora Annex") ||
      roomKey.includes("Resource Colony Fauna Annex")
    ) {
      return 24;
    }
    return 5;
  }
  if (zoneId === "killstar-annex") {
    return roomKey === "Marcus Killstar Mining Annex" ||
      roomKey === "Marcus Killstar Flora Annex" ||
      roomKey === "Marcus Killstar Fauna Annex"
      ? 22
      : 5;
  }
  if (zoneId === "field-extraction") return hasMiningSite ? 7 : 9;
  return 12;
}

export function treemapFootprintForParcelTier(tier: number): number {
  const t = Math.max(1, Math.min(3, tier));
  if (t >= 3) return 22;
  if (t === 2) return 14;
  return 9;
}

export function shortRoomLabel(roomKey: string): string {
  if (roomKey.length <= 26) return roomKey;
  return `${roomKey.slice(0, 24)}…`;
}

export type LocatorTreemapBranch = {
  name: string;
  value?: number;
  children?: LocatorTreemapBranch[];
};

export type LocatorTreemapLeafData = LocatorTreemapBranch & {
  name: string;
  value: number;
  roomKey: string;
  roomId: number;
  playerCount: number;
  hasMiningSite: boolean;
  parcelSummary?: boolean;
  parcelTier?: number;
  parcelZone?: string;
};

function leafFromRoom(r: WorldGraphRoom, zoneId: LocatorZoneId): LocatorTreemapLeafData {
  const value = treemapFootprintForRoom(r.key, zoneId, r.hasMiningSite);
  return {
    name: shortRoomLabel(r.key),
    value,
    roomKey: r.key,
    roomId: r.id,
    playerCount: r.playerCount ?? 0,
    hasMiningSite: r.hasMiningSite,
  };
}

function sortRooms(list: WorldGraphRoom[]): WorldGraphRoom[] {
  return list.slice().sort((a, b) => a.key.localeCompare(b.key));
}

type InteriorEntry = { room: WorldGraphRoom; zone: LocatorZoneId };

const TOP_LEVEL_ORDER: LocatorZoneId[] = [
  "arrival",
  "industrial-colony",
  "plex-industrial",
  "killstar-annex",
  "field-extraction",
  "other",
];

function labelForPlexVenue(venueId: string, catalog: WorldGraphVenueRow[]): string {
  if (venueId === "nanomega_core") return "Plex industrial";
  if (venueId === "frontier_outpost") return "Frontier industrial";
  if (venueId === NONE_VENUE) return "Industrial pads";
  const row = catalog.find((c) => c.id === venueId);
  return row ? `${row.label} industrial` : `${venueId} industrial`;
}

export type StationTreemapBuild = {
  data: LocatorTreemapBranch[];
  maxPlayerCount: number;
  empty: boolean;
};

/**
 * Treemap: one sector per venue label for interior zones; shared sectors split when useful.
 */
export function buildStationTreemapData(
  rooms: WorldGraphRoom[],
  filter: string,
  venueCatalog: WorldGraphVenueRow[] = [],
  locatorParcels: LocatorParcelRow[] | undefined = undefined,
): StationTreemapBuild {
  const q = filter.trim().toLowerCase();
  const filtered = q ? rooms.filter((r) => r.key.toLowerCase().includes(q)) : rooms;

  const roomKeyById = new Map(filtered.map((r) => [r.id, r.key]));
  const playerCountByRoomId = new Map(filtered.map((r) => [r.id, r.playerCount ?? 0]));

  const parcelsByVenue = new Map<string, LocatorParcelRow[]>();
  for (const p of locatorParcels ?? []) {
    if (q && !p.lotKey.toLowerCase().includes(q)) continue;
    const list = parcelsByVenue.get(p.venueId);
    if (list) list.push(p);
    else parcelsByVenue.set(p.venueId, [p]);
  }
  for (const list of parcelsByVenue.values()) {
    list.sort((a, b) => a.lotKey.localeCompare(b.lotKey));
  }

  const interiorByVenue = new Map<string, InteriorEntry[]>();
  const buckets = new Map<LocatorZoneId, WorldGraphRoom[]>();
  for (const z of ZONE_ORDER) buckets.set(z, []);

  for (const r of filtered) {
    const z = zoneForRoom(r);
    if (isMegaplexInteriorZone(z)) {
      const vk = venueKey(r);
      const list = interiorByVenue.get(vk);
      const entry: InteriorEntry = { room: r, zone: z };
      if (list) list.push(entry);
      else interiorByVenue.set(vk, [entry]);
    } else {
      buckets.get(z)!.push(r);
    }
  }

  const data: LocatorTreemapBranch[] = [];
  const usedInteriorVenues = new Set<string>();

  for (const { id, label } of venueCatalog) {
    const entries = interiorByVenue.get(id);
    if (entries?.length) {
      usedInteriorVenues.add(id);
      entries.sort((a, b) => a.room.key.localeCompare(b.room.key));
      data.push({
        name: label,
        children: entries.map((e) => leafFromRoom(e.room, e.zone)),
      });
    }
    const venueParcels = parcelsByVenue.get(id);
    if (venueParcels?.length) {
      data.push({
        name: `${label} titled parcels`,
        children: venueParcels.map((p) => {
          const interiorId = p.interiorRoomId;
          const rk =
            interiorId != null ? (roomKeyById.get(interiorId) ?? "") : "";
          return {
            name: shortRoomLabel(p.lotKey),
            value: treemapFootprintForParcelTier(p.tier),
            roomKey: rk,
            roomId: interiorId ?? -p.holdingId,
            playerCount: interiorId != null ? (playerCountByRoomId.get(interiorId) ?? 0) : 0,
            hasMiningSite: false,
            parcelSummary: true,
            parcelTier: p.tier,
            parcelZone: p.zone,
          } satisfies LocatorTreemapLeafData;
        }),
      });
    }
  }

  const catalogVenueIds = new Set(venueCatalog.map((c) => c.id));

  const orphanInteriorIds = [...interiorByVenue.keys()].filter((k) => !usedInteriorVenues.has(k));
  orphanInteriorIds.sort();
  for (const vid of orphanInteriorIds) {
    const entries = interiorByVenue.get(vid)!;
    entries.sort((a, b) => a.room.key.localeCompare(b.room.key));
    const name = vid === NONE_VENUE ? "Station" : vid;
    data.push({
      name,
      children: entries.map((e) => leafFromRoom(e.room, e.zone)),
    });
  }

  for (const vid of [...parcelsByVenue.keys()].sort()) {
    if (catalogVenueIds.has(vid)) continue;
    const orphanParcels = parcelsByVenue.get(vid)!;
    const branchName = vid === NONE_VENUE ? "Station titled parcels" : `${vid} titled parcels`;
    data.push({
      name: branchName,
      children: orphanParcels.map((p) => {
        const interiorId = p.interiorRoomId;
        const rk = interiorId != null ? (roomKeyById.get(interiorId) ?? "") : "";
        return {
          name: shortRoomLabel(p.lotKey),
          value: treemapFootprintForParcelTier(p.tier),
          roomKey: rk,
          roomId: interiorId ?? -p.holdingId,
          playerCount: interiorId != null ? (playerCountByRoomId.get(interiorId) ?? 0) : 0,
          hasMiningSite: false,
          parcelSummary: true,
          parcelTier: p.tier,
          parcelZone: p.zone,
        } satisfies LocatorTreemapLeafData;
      }),
    });
  }

  for (const z of TOP_LEVEL_ORDER) {
    const list = sortRooms(buckets.get(z) ?? []);
    if (list.length === 0) continue;

    if (z === "plex-industrial") {
      const preferred = ["nanomega_core", "frontier_outpost", NONE_VENUE];
      const seen = new Set<string>();
      for (const vid of preferred) {
        const sub = list.filter((r) => venueKey(r) === vid);
        if (!sub.length) continue;
        seen.add(vid);
        data.push({
          name: labelForPlexVenue(vid, venueCatalog),
          children: sub.map((r) => leafFromRoom(r, z)),
        });
      }
      const restIds = [...new Set(list.map(venueKey))].filter((id) => !seen.has(id)).sort();
      for (const vid of restIds) {
        const sub = list.filter((r) => venueKey(r) === vid);
        data.push({
          name: labelForPlexVenue(vid, venueCatalog),
          children: sub.map((r) => leafFromRoom(r, z)),
        });
      }
      continue;
    }

    const label =
      z === "arrival"
        ? "Arrival"
        : z === "industrial-colony"
          ? "Industrial resource colony"
          : z === "killstar-annex"
            ? "Killstar annex"
            : z === "field-extraction"
              ? "Field & claims"
              : "Other";
    data.push({
      name: label,
      children: list.map((r) => leafFromRoom(r, z)),
    });
  }

  const maxPlayerCount = Math.max(0, ...filtered.map((r) => r.playerCount ?? 0));

  return {
    data,
    maxPlayerCount,
    empty: data.length === 0,
  };
}
