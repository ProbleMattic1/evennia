/**
 * Zoned layout for the Universal Locator grid view.
 * Server sends locatorZone from VENUES; rules below are legacy fallback only.
 */

export const HUB_ROOM_KEY = "NanoMegaPlex Promenade";

export type LocatorZoneId =
  | "arrival"
  | "core-hub"
  | "core-services"
  | "core-retail"
  | "realty-property"
  | "meridian-shipping"
  | "nanomega-agency"
  | "industrial-colony"
  | "plex-industrial"
  | "killstar-annex"
  | "field-extraction"
  | "other";

const VALID_LOCATOR_ZONES = new Set<string>([
  "arrival",
  "core-hub",
  "core-services",
  "core-retail",
  "realty-property",
  "meridian-shipping",
  "nanomega-agency",
  "industrial-colony",
  "plex-industrial",
  "killstar-annex",
  "field-extraction",
  "other",
]);

/** Promenade-adjacent areas nested under each venue’s treemap sector. */
export const MEGAPLEX_INTERIOR_ZONE_IDS: readonly LocatorZoneId[] = [
  "core-hub",
  "core-retail",
  "core-services",
  "realty-property",
  "meridian-shipping",
  "nanomega-agency",
] as const;

export function isMegaplexInteriorZone(zoneId: LocatorZoneId): boolean {
  return (MEGAPLEX_INTERIOR_ZONE_IDS as readonly string[]).includes(zoneId);
}

type ZoneRule = { zoneId: LocatorZoneId; test: (key: string) => boolean };

const ZONE_RULES: ZoneRule[] = [
  { zoneId: "arrival", test: (k) => k === "Frontier Transit Shell" },
  {
    zoneId: "core-hub",
    test: (k) => k === HUB_ROOM_KEY || k === "Frontier Promenade",
  },
  {
    zoneId: "core-services",
    test: (k) =>
      k === "Alpha Prime Central Reserve" ||
      k === "Aurnom Ore Processing Plant" ||
      k === "Aurnom Flora Processing Plant" ||
      k === "Aurnom Fauna Processing Plant" ||
      k === "Frontier Alpha Prime Reserve" ||
      k === "Frontier Ore Processing Plant",
  },
  {
    zoneId: "core-retail",
    test: (k) =>
      k === "Aurnom Tech Depot" ||
      k === "Aurnom Mining Outfitters" ||
      k === "Aurnom General Supply" ||
      k === "Aurnom Toy Gallery" ||
      k === "Frontier Aurnom Tech Depot" ||
      k === "Frontier Aurnom Mining Outfitters" ||
      k === "Frontier Aurnom General Supply" ||
      k === "Frontier Aurnom Toy Gallery",
  },
  {
    zoneId: "realty-property",
    test: (k) =>
      k === "NanoMegaPlex Real Estate Office" ||
      k === "Property Lots Archive" ||
      k === "Frontier Real Estate Office" ||
      k === "Frontier Property Lots Archive",
  },
  {
    zoneId: "meridian-shipping",
    test: (k) =>
      k === "Meridian Civil Shipyard" ||
      k === "Meridian Delivery Hangar" ||
      k === "Frontier Meridian Civil Shipyard" ||
      k === "Frontier Meridian Delivery Hangar" ||
      k === "Low Meridian Orbit",
  },
  {
    zoneId: "nanomega-agency",
    test: (k) =>
      k === "NanoMegaPlex Advertising Agency" || k === "Frontier Advertising Agency",
  },
  {
    zoneId: "industrial-colony",
    test: (k) =>
      k === "Industrial Resource Colony Grid" ||
      k.startsWith("Industrial Resource Colony Pad ") ||
      k === "Ashfall Industrial Grid" ||
      k.startsWith("Ashfall Industrial Pad ") ||
      k === "Industrial Resource Colony Flora Annex" ||
      k === "Industrial Resource Colony Fauna Annex" ||
      k.startsWith("Industrial Resource Colony Flora Pad ") ||
      k.startsWith("Industrial Resource Colony Fauna Pad "),
  },
  {
    zoneId: "plex-industrial",
    test: (k) =>
      k === "NanoMegaPlex Industrial Subdeck" ||
      k.startsWith("NanoMegaPlex Industrial Pad ") ||
      k === "NanoMegaPlex Resource Colony Flora Annex" ||
      k === "NanoMegaPlex Resource Colony Fauna Annex" ||
      k.startsWith("NanoMegaPlex Resource Colony Flora Pad ") ||
      k.startsWith("NanoMegaPlex Resource Colony Fauna Pad ") ||
      k === "Frontier Industrial Subdeck" ||
      k.startsWith("Frontier Industrial Pad ") ||
      k === "Frontier Resource Colony Flora Annex" ||
      k === "Frontier Resource Colony Fauna Annex" ||
      k.startsWith("Frontier Resource Colony Flora Pad ") ||
      k.startsWith("Frontier Resource Colony Fauna Pad "),
  },
  {
    zoneId: "killstar-annex",
    test: (k) =>
      k === "Marcus Killstar Mining Annex" ||
      k === "Marcus Killstar Flora Annex" ||
      k === "Marcus Killstar Fauna Annex" ||
      k.startsWith("Marcus Killstar Pad ") ||
      k.startsWith("Marcus Killstar Flora Pad ") ||
      k.startsWith("Marcus Killstar Fauna Pad "),
  },
];

/** Display order for grid sections */
export const ZONE_ORDER: LocatorZoneId[] = [
  "arrival",
  "core-hub",
  "core-services",
  "core-retail",
  "realty-property",
  "meridian-shipping",
  "nanomega-agency",
  "industrial-colony",
  "plex-industrial",
  "killstar-annex",
  "field-extraction",
  "other",
];

export const ZONE_LABELS: Record<
  LocatorZoneId,
  { title: string; subtitle: string }
> = {
  arrival: { title: "Arrival & rim", subtitle: "Frontier transit" },
  "core-hub": { title: "Promenade core", subtitle: "Venue hub" },
  "core-services": {
    title: "Sovereign & industry services",
    subtitle: "Bank, ore / flora / fauna processing",
  },
  "core-retail": { title: "Retail concourse", subtitle: "Depot, outfitters, supply, gallery" },
  "realty-property": { title: "Property & titles", subtitle: "Real estate office, archive" },
  "meridian-shipping": { title: "Meridian shipping", subtitle: "Shipyard & delivery" },
  "nanomega-agency": { title: "Agency band", subtitle: "Advertising & campaigns" },
  "industrial-colony": {
    title: "Industrial resource colony",
    subtitle: "Contract pads — basin supply",
  },
  "plex-industrial": { title: "Industrial subdeck & pads", subtitle: "Venue contractor grid" },
  "killstar-annex": { title: "Killstar mining annex", subtitle: "Leased pads — catalog feedstock" },
  "field-extraction": {
    title: "Perimeter extraction & claims",
    subtitle: "Registered field sites & open deposits",
  },
  other: { title: "Other locations", subtitle: "Unclassified rooms" },
};

export function assignZoneId(
  roomKey: string,
  hasMiningSite: boolean,
  serverZone?: string | null,
): LocatorZoneId {
  const z = serverZone === "ashfall-industrial" ? "industrial-colony" : serverZone;
  if (z && VALID_LOCATOR_ZONES.has(z)) {
    return z as LocatorZoneId;
  }
  for (const rule of ZONE_RULES) {
    if (rule.test(roomKey)) return rule.zoneId;
  }
  if (hasMiningSite) return "field-extraction";
  return "other";
}
