/**
 * Volume vs rarity use separate maps: the API reuses keys (e.g. "amber" for
 * Moderate volume and Uncommon rarity). Volume tiers use a blue scale (API
 * key "emerald" = Rich → indigo; "sky" = Deep → sky blue). Rarity keeps its
 * own palette (Common → fuchsia). Moderate = light cyan; Rich = solid indigo;
 * Deep = navy chip — avoids pastel-on-pastel confusion between Moderate and Rich.
 */

/** Volume tiers (Lean→Deep) share a blue scale; keys mirror API (`emerald` = Rich). */
const VOL_ZINC_BADGE =
  "bg-blue-50 text-blue-900 ring-1 ring-blue-200 dark:bg-blue-950/70 dark:text-blue-300 dark:ring-blue-800/50";
const VOL_ZINC_TEXT = "text-blue-800 dark:text-blue-400";

const RAR_ZINC_BADGE =
  "bg-fuchsia-100 text-fuchsia-900 ring-1 ring-fuchsia-300 dark:bg-fuchsia-950 dark:text-fuchsia-300 dark:ring-fuchsia-800/50";
const RAR_ZINC_TEXT = "text-fuchsia-700 dark:text-fuchsia-400";

export type TierStyle = { badge: string; text: string };

export const VOLUME_TIER_STYLES: Record<string, TierStyle> = {
  sky: {
    text: "text-blue-900 dark:text-blue-300",
    badge:
      "bg-blue-950 text-blue-50 ring-1 ring-blue-800 dark:bg-blue-950 dark:text-blue-100 dark:ring-blue-600/70",
  },
  emerald: {
    text: "text-indigo-800 dark:text-indigo-300",
    badge:
      "bg-indigo-600 text-white ring-1 ring-indigo-500 shadow-sm dark:bg-indigo-600 dark:text-white dark:ring-indigo-400",
  },
  amber: {
    text: "text-cyan-800 dark:text-cyan-400",
    badge:
      "bg-cyan-100 text-cyan-950 ring-1 ring-cyan-400 dark:bg-cyan-950 dark:text-cyan-200 dark:ring-cyan-600/55",
  },
  zinc: {
    text: VOL_ZINC_TEXT,
    badge: VOL_ZINC_BADGE,
  },
};

export const RARITY_TIER_STYLES: Record<string, TierStyle> = {
  violet: {
    text: "text-violet-600 dark:text-violet-400",
    badge:
      "bg-violet-100 text-violet-800 ring-1 ring-violet-300 dark:bg-violet-950 dark:text-violet-400 dark:ring-violet-700/50",
  },
  amber: {
    text: "text-amber-600 dark:text-amber-400",
    badge:
      "bg-amber-100 text-amber-800 ring-1 ring-amber-300 dark:bg-amber-950 dark:text-amber-400 dark:ring-amber-700/50",
  },
  zinc: {
    text: RAR_ZINC_TEXT,
    badge: RAR_ZINC_BADGE,
  },
};

const VOL_FALLBACK = VOLUME_TIER_STYLES.zinc;
const RAR_FALLBACK = RARITY_TIER_STYLES.zinc;

export function volumeTierStyle(cls: string | null | undefined): TierStyle {
  if (!cls) return VOL_FALLBACK;
  return VOLUME_TIER_STYLES[cls] ?? VOL_FALLBACK;
}

export function rarityTierStyle(cls: string | null | undefined): TierStyle {
  if (!cls) return RAR_FALLBACK;
  return RARITY_TIER_STYLES[cls] ?? RAR_FALLBACK;
}
