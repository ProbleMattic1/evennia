/** Key + display name pairs (e.g. market commodity or resources catalog entry). */
export type ResourceKeyName = { key: string; name: string };

export function buildResourceNameLookup(entries: ResourceKeyName[]): Map<string, string> {
  const m = new Map<string, string>();
  for (const e of entries) {
    if (e.key) {
      m.set(e.key, e.name);
    }
  }
  return m;
}

/** Prefer catalog name; fallback: snake_case → spaces (not full title case). */
export function displayResourceName(key: string, lookup: Map<string, string>): string {
  const n = lookup.get(key);
  if (n) return n;
  return key.replace(/_/g, " ");
}

export type CompositionLine = { key: string; displayName: string; pct: number };

export function compositionToLines(comp: Record<string, number>, lookup: Map<string, string>): CompositionLine[] {
  return Object.entries(comp).map(([k, v]) => ({
    key: k,
    displayName: displayResourceName(k, lookup),
    pct: Math.round(Number(v) * 100),
  }));
}
