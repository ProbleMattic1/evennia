import { UI_PREFIX } from "./ui-endpoints";

export type StoryLine = {
  id: string;
  text: string;
  kind: "title" | "room" | "system";
};

export type ExitButton = {
  key: string;
  label: string;
  command: string;
  destination: string | null;
  /** Human-readable section title from the server */
  section?: string;
  sectionKey?: string;
  sectionOrder?: number;
  order?: number;
};

export type PlayAction = {
  key: string;
  label: string;
  href: string;
};

export type MineRigRow = {
  key: string;
  rating: number;
  wear: number;
  operational: boolean;
  mode?: string;
  powerLevel?: string;
  targetFamily?: string;
  purityCutoff?: string;
  maintenanceLevel?: string;
  needsRepair?: boolean;
  repairTotalCr?: number | null;
  repairTaxCr?: number | null;
  repairVendorCr?: number | null;
};

export type MineSiteDetails = {
  id: number;
  key: string;
  siteKey: string;
  roomKey: string;
  location: string | null;
  isClaimed: boolean;
  owner: string | null;
  canUndeploy?: boolean;
  mineOperationActive?: boolean;
  canListProperty?: boolean;
  canReactivate?: boolean;
  surveyLevel: number;
  richness: number;
  volumeTier: string;
  volumeTierCls: string;
  resourceRarityTier: string;
  resourceRarityTierCls: string;
  baseOutputTons: number;
  composition: Record<string, number>;
  resources: string;
  depletionRate: number;
  richnessFloor: number;
  licenseLevel: number;
  taxRate: number;
  hazardLevel: number;
  hazardLabel: string;
  nextCycleAt: string | null;
  lastProcessedAt: string | null;
  cycleLog: string[];
  hazardLog: string[];
  estimatedValuePerCycle: number;
  active: boolean;
  rig: string | null;
  rigRating: number | null;
  rigWear: number | null;
  rigOperational: boolean | null;
  rigMode: string | null;
  rigPowerLevel: string | null;
  rigTargetFamily: string | null;
  rigPurityCutoff: string | null;
  rigMaintenanceLevel: string | null;
  rigs?: MineRigRow[];
  storageUsed: number;
  storageCapacity: number;
  inventory: Record<string, number>;
};

export type PlayState = {
  roomName: string;
  roomDescription: string;
  storyLines: StoryLine[];
  exits: ExitButton[];
  actions: PlayAction[];
  /** Shared mining grid next boundary; prefer over site.nextCycleAt for timers. */
  miningNextCycleAt?: string | null;
  site?: MineSiteDetails;
};

export type MsgStreamEntry = {
  seq: number;
  html: string;
  ts: number;
  meta: {
    eventType: string;
    interactionKey: string | null;
    speakerKey: string | null;
    destinationRoomKey: string | null;
  };
};

export type MsgStreamResponse = {
  ok: boolean;
  messages: MsgStreamEntry[];
  seq: number;
};

export type NavShopLink = {
  roomKey: string;
  label: string;
};

export type NavKiosk = {
  key: string;
  label: string;
  href: string;
};

export type NavClaimLink = {
  label: string;
  href: string;
};

export type NavPropertyLink = {
  label: string;
  href: string;
};

export type NavState = {
  hubRoomKey: string;
  exits: ExitButton[];
  mines?: ExitButton[];
  claims?: NavClaimLink[];
  properties?: NavPropertyLink[];
  shops: NavShopLink[];
  kiosks: NavKiosk[];
};

export type WorldGraphVenueRow = { id: string; label: string };

export type LocatorParcelRow = {
  holdingId: number;
  lotId: number;
  lotKey: string;
  venueId: string;
  anchorRoomId: number;
  tier: number;
  zone: string;
  interiorRoomId: number | null;
};

export type WorldGraphRoom = {
  id: number;
  key: string;
  hasMiningSite: boolean;
  playerCount?: number;
  venueId?: string | null;
  locatorZone?: string;
};

export type WorldGraphEdge = {
  fromId: number;
  toId: number;
  fromKey: string;
  toKey: string;
  exitKey: string;
};

export type WorldGraphState = {
  schemaVersion: number;
  generatedAt: string;
  venueCatalog?: WorldGraphVenueRow[];
  rooms: WorldGraphRoom[];
  edges: WorldGraphEdge[];
  edgesAll: WorldGraphEdge[];
  currentRoomKey: string | null;
  reachableRoomIds: number[] | null;
  adjacentRoomKeys: string[] | null;
  locatorParcels?: LocatorParcelRow[];
};

export type LedgerTransactionRow = {
  timestamp: string;
  type: string;
  amount: number;
  memo: string;
  fromAccount: string | null;
  toAccount: string | null;
  signedAmount: number;
  extra: Record<string, string | number | boolean | null>;
};

export type BankState = {
  venueId?: string;
  bankName: string;
  roomName: string;
  roomDescription: string;
  treasuryBalance: number;
  /** Ledger key for sovereign receipts/disbursements (e.g. treasury:alpha-prime). */
  treasuryAccount: string;
  storyLines: StoryLine[];
  exits: ExitButton[];
  /** Public: every economy row touching the treasury (newest first). signedAmount = Δ to treasury. */
  treasuryTransactionLog: LedgerTransactionRow[];
  credits?: number;
  transactionLog?: LedgerTransactionRow[];
};

export type ProcessingHaulerMode = {
  id: number;
  key: string;
  deliveryMode: "ore_receiving_bay" | "local_raw_reserve" | "sell" | "process";
};

/** One plant-accepted raw commodity row in the shared Ore Receiving Bay. */
export type OreReceivingBayRow = {
  key: string;
  displayName: string;
  tons: number;
  estimatedValueCr: number;
};

export type ProcessingState = {
  venueId?: string;
  plantName: string;
  roomName: string;
  roomDescription: string;
  storyLines: StoryLine[];
  exits: ExitButton[];
  /** Dense catalog rows (mining + flora + fauna raw); bay may hold extra unknown keys. */
  oreReceivingBay: OreReceivingBayRow[];
  rawStorageUsed: number;
  rawStorageCapacity: number;
  refineryInputTons: number;
  refineryOutputValue: number;
  /** Sum of all per-owner miner_ore_queue ore (attributed plant input). */
  minerQueueOreTons: number;
  /** Gross cr value of all attributed miner_output (before processing fee). */
  minerOutputValueTotal: number;
  processingFeeRate: number;
  rawSaleFeeRate: number;
  rawAskPremiumRate: number;
  myOreQueued: number | null;
  myRefinedOutput: Record<string, number> | null;
  myRefinedOutputValue: number | null;
  myHaulers: ProcessingHaulerMode[] | null;
};

export type CatalogEntry = {
  id: string;
  key: string;
  description: string;
  summary: string;
  price: number | null;
};

export type ShopState = {
  catalogMode: "items" | "ships";
  vendorId: string;
  shopName: string;
  roomName: string;
  roomDescription: string;
  ships: CatalogEntry[];
  items: CatalogEntry[];
  exits: ExitButton[];
  storyLines: StoryLine[];
};

export type DashboardAbility = {
  name: string;
  score: number;
  base: number;
  mod: number;
  abilityMod: number;
};

export type DashboardVitalGauge = {
  name: string;
  current: number;
  max: number | null;
};

export type DashboardVitals = {
  hp?: DashboardVitalGauge;
};

export type DashboardCharacter = {
  id: number;
  key: string;
  room: string | null;
  abilities: Record<string, DashboardAbility>;
  vitals: DashboardVitals;
  armorClass: number;
};

export type ClaimSpecs = {
  roomKey: string;
  richness: number;
  baseOutputTons: number;
  composition: Record<string, number>;
  hazardLevel: number;
  hazardLabel: string;
  estimatedValuePerCycle: number;
  volumeTier?: string;
  volumeTierCls?: string;
  resourceRarityTier?: string;
  resourceRarityTierCls?: string;
};

export type DashboardInventoryItem = {
  id: number;
  key: string;
  description: string;
  isMiningPackage?: boolean;
  isMiningClaim?: boolean;
  claimSpecs?: ClaimSpecs;
  estimatedValue?: number;
  count?: number;
  stacked?: boolean;
  ids?: number[];
};

export type DashboardShip = {
  id: number;
  key: string;
  location: string | null;
  pilot: string | null;
  state: string | null;
  summary: string;
  is_autonomous?: boolean;
  /** Stable grouping key from server (vehicle_type_slug or derived). */
  vehicleClassSlug?: string;
  /** Human-readable class name for section headers. */
  vehicleClassLabel?: string;
  count?: number;
  stacked?: boolean;
  ids?: number[];
  locations?: (string | null)[];
};

export type DashboardMine = {
  id: number;
  key: string;
  /** Canonical production-site kind from the server (`mining_site` | `flora_site`). */
  kind?: string;
  /** Legacy flora/mining hint; prefer ``kind``. */
  siteKind?: string;
  location: string | null;
  active: boolean;
  richness: number;
  volumeTier?: string;
  volumeTierCls?: string;
  resourceRarityTier?: string;
  resourceRarityTierCls?: string;
  baseOutputTons: number;
  estimatedOutputTons?: number;
  estimatedValuePerCycle?: number;
  composition: Record<string, number>;
  nextCycleAt: string | null;
  rigs?: { key: string; wear: number; operational: boolean }[];
  rig: string | null;
  rigWear: number | null;
  rigOperational: boolean;
  storageUsed: number;
  storageCapacity: number;
  inventory: Record<string, number>;
  licenseLevel: number;
  taxRate: number;
  hazardLevel: number;
  /** Epoch-aligned delivery grid length for this site (mining vs flora). */
  deliveryPeriodSeconds?: number;
  /** Value actually accruing this cycle (0 when inactive / no contributing rig). */
  accrualValuePerCycle?: number;
};

export type DashboardProperty = {
  claimId: number;
  claimKey: string;
  lotKey: string;
  tier: number;
  zone: string;
  referenceListPriceCr: number | null;
  structureUpgradesAvailable?: boolean;
  hasBuiltOnParcel?: boolean;
  /** Primary-market realty office venue (Nano vs Frontier); omitted when unknown. */
  realtyAgent?: "nano" | "frontier" | null;
};

export type DashboardAlert = {
  id: string;
  severity: "critical" | "warning" | "info";
  category: "mining" | "market" | "system";
  title: string;
  detail?: string;
  source?: string;
  createdAt: string;
};

export type DashboardGroupedAlerts = {
  critical: DashboardAlert[];
  warning: DashboardAlert[];
  info: DashboardAlert[];
};

export type MissionMorality = {
  good: number;
  evil: number;
  lawful: number;
  chaotic: number;
};

export type MissionOpportunity = {
  id: string;
  templateId: string;
  title: string;
  summary: string;
  storylineId?: string;
  threadId?: string;
  giver?: Record<string, unknown>;
  source?: Record<string, unknown>;
  sourceKey?: string;
  createdAt: string;
};

export type MissionChoice = {
  id: string;
  label: string;
  outcome?: string;
  morality?: Partial<MissionMorality>;
  rewards?: Record<string, unknown>;
  nextObjectiveId?: string | null;
  unlockTemplateIds?: string[];
  completeMission?: boolean;
};

export type MissionObjective = {
  id: string;
  kind: "visit_room" | "interaction" | "choice" | string;
  text?: string;
  prompt?: string;
  choices?: MissionChoice[];
  roomKeysAny?: string[];
  interactionKeysAny?: string[];
};

export type MissionChoiceLog = {
  objectiveId: string;
  choiceId: string;
  chosenAt: string;
  outcome?: string;
};

export type MissionActive = {
  id: string;
  templateId: string;
  title: string;
  summary: string;
  storylineId?: string;
  threadId?: string;
  status: "active" | "completed" | string;
  createdAt: string;
  acceptedAt?: string;
  completedAt?: string | null;
  currentObjective?: MissionObjective | null;
  choices?: MissionChoiceLog[];
};

/** Character-carried items from /ui/dashboard and /ui/control-surface (taxonomic buckets). */
export type CarriedInventoryPayload = {
  byBucket: Record<string, DashboardInventoryItem[]>;
  bucketOrder: string[];
  bucketLabels: Record<string, string>;
};

export type DashboardState = {
  authenticated: boolean;
  character: DashboardCharacter | null;
  credits: number | null;
  inventory: CarriedInventoryPayload;
  ships: DashboardShip[];
  /** Same rows as ``mines`` when provided by the server. */
  resources?: DashboardMine[];
  mines?: DashboardMine[];
  properties?: DashboardProperty[];
  propertyReferenceListValueTotalCr?: number;
  miningEstimatedValuePerCycle?: number;
  miningTotalStoredValue?: number;
  treasuryBalance: number | null;
  message: string | null;
  alerts?: DashboardAlert[];
  groupedAlerts?: DashboardGroupedAlerts;
  missions?: MissionsState;
};

export type MissionsState = {
  morality: MissionMorality;
  opportunities: MissionOpportunity[];
  active: MissionActive[];
  completed: MissionActive[];
};

// ---------------------------------------------------------------------------
// Cadence challenges
// ---------------------------------------------------------------------------

export type ChallengeStatus = "in_progress" | "complete" | "claimed" | "expired";

export type ChallengeActive = {
  challengeId: string;
  cadence: string;
  windowKey: string;
  title: string;
  summary: string;
  status: ChallengeStatus;
  startedAt: string | null;
  completedAt: string | null;
  progress: Record<string, unknown>;
  rewardsGranted?: boolean;
};

export type ChallengeHistoryRow = {
  challengeId: string;
  cadence: string;
  windowKey: string;
  completedAt: string;
  claimed: boolean;
  /** Human-readable title from challenge template (same as active challenges). */
  title: string;
};

export type ChallengesState = {
  active: ChallengeActive[];
  history: ChallengeHistoryRow[];
  windows: Record<string, string>;
  pointsLifetime?: number;
  pointsSeason?: number;
  seasonId?: string;
};

export type ChallengeClaimResult = {
  ok: boolean;
  message?: string;
  challenges?: ChallengesState;
  claimedCount?: number;
};

export type ResourceEntry = {
  key: string;
  name: string;
  category: string;
  basePriceCrPerTon: number;
  desc: string;
};

export type ResourcesState = {
  resources: ResourceEntry[];
};

async function readJson<T>(res: Response): Promise<T> {
  const text = await res.text();
  try {
    return JSON.parse(text) as T;
  } catch {
    throw new Error(text || res.statusText || "Invalid JSON");
  }
}

async function getUi<T>(path: string, search?: Record<string, string | undefined>): Promise<T> {
  const qs = new URLSearchParams();
  if (search) {
    for (const [k, v] of Object.entries(search)) {
      if (v !== undefined && v !== "") {
        qs.set(k, v);
      }
    }
  }
  const suffix = qs.toString();
  const url = `${UI_PREFIX}/${path}${suffix ? `?${suffix}` : ""}`;
  const res = await fetch(url, {
    credentials: "include",
    cache: "no-store",
  });
  if (!res.ok) {
    let message: string | undefined;
    try {
      const body = await readJson<{ message?: string }>(res);
      message = body.message;
    } catch {
      message = undefined;
    }
    throw new Error(message ?? `Request failed (${res.status})`);
  }
  return readJson<T>(res);
}

export function getPlayState(room?: string): Promise<PlayState> {
  return getUi<PlayState>("play", { room });
}

export function getMsgStream(since: number): Promise<MsgStreamResponse> {
  return getUi<MsgStreamResponse>("msg-stream", { since: String(since) });
}

export function getNavState(): Promise<NavState> {
  return getUi<NavState>("nav");
}

export function fetchWorldGraph(): Promise<WorldGraphState> {
  return getUi<WorldGraphState>("world-graph");
}

export function getBankState(venue?: string): Promise<BankState> {
  return getUi<BankState>("bank", venue ? { venue } : undefined);
}

export function getProcessingState(venue?: string): Promise<ProcessingState> {
  return getUi<ProcessingState>("processing", venue ? { venue } : undefined);
}

export function getShopState(room: string): Promise<ShopState> {
  return getUi<ShopState>("shop", { room });
}

export function getDashboardState(): Promise<DashboardState> {
  return getUi<DashboardState>("dashboard");
}

export function getResources(): Promise<ResourcesState> {
  return getUi<ResourcesState>("resources");
}

async function postUi<T>(path: string, body: Record<string, unknown>): Promise<T> {
  const res = await fetch(`${UI_PREFIX}/${path}`, {
    method: "POST",
    credentials: "include",
    cache: "no-store",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  const data = await readJson<T & { ok?: boolean; message?: string }>(res);
  if (!res.ok || (typeof data === "object" && data && "ok" in data && data.ok === false)) {
    throw new Error(
      typeof data === "object" && data && "message" in data && typeof data.message === "string"
        ? data.message
        : `Request failed (${res.status})`
    );
  }
  return data;
}

export type InspectItemResult = {
  ok: boolean;
  message?: string;
  item?: CatalogEntry;
  ship?: CatalogEntry & { summary?: string };
  state?: ShopState;
};

export async function inspectItem(params: {
  room: string;
  itemId?: string;
  shipId?: string;
  name?: string;
}): Promise<InspectItemResult> {
  return postUi<InspectItemResult>("shop/inspect", {
    room: params.room,
    itemId: params.itemId ?? params.shipId,
    name: params.name,
  });
}

export async function buyItem(params: {
  room: string;
  itemId?: string;
  shipId?: string;
  name?: string;
}): Promise<{
  ok: boolean;
  message?: string;
  state?: ShopState;
}> {
  return postUi("shop/buy", {
    room: params.room,
    itemId: params.itemId ?? params.shipId,
    name: params.name,
  });
}

export type MarketCommodity = {
  key: string;
  name: string;
  category: "standard_metal" | "exotic_metal" | "gem_bearing";
  basePriceCrPerTon: number;
  sellPriceCrPerTon: number;
  buyPriceCrPerTon: number;
  desc: string;
};

export type MarketState = {
  commodities: MarketCommodity[];
};

export function getMarketState(): Promise<MarketState> {
  return getUi<MarketState>("market");
}

export type EconomyWorldMeter = {
  id: string;
  kind: "linear_accruing";
  unit: string;
  label: string;
  startAtIso: string;
  endAtIso: string;
  valueAtStart: number;
  valueAtEnd: number;
  note?: string;
};

export type EconomyWorldPayload = {
  schemaVersion: number;
  serverTimeIso: string;
  miningDeliveryPeriodSeconds: number;
  miningNextCycleAt: string;
  miningSlotStartAt: string;
  world: Record<string, unknown>;
  meters: EconomyWorldMeter[];
  market: MarketCommodity[];
};

export function getEconomyWorldState(): Promise<EconomyWorldPayload> {
  return getUi<EconomyWorldPayload>("economy-world");
}

export type ClaimsMarketClaim = {
  siteKey: string;
  roomKey: string;
  resources: string;
  richness: number;
  volumeTier: string;
  volumeTierCls: string;
  resourceRarityTier: string;
  resourceRarityTierCls: string;
  hazardLevel: number;
  hazardLabel: string;
  baseOutputTons: number;
  listingPriceCr: number;
  purchasable: boolean;
  playerListing?: boolean;
  sellerKey?: string;
  listingKind?: "npc" | "property" | "deed";
  claimId?: number;
  claimKey?: string;
};

export type RandomMiningClaimQuote = {
  templateKey: string;
  priceCr: number;
};

export type ClaimsMarketState = {
  claims: ClaimsMarketClaim[];
  nextDiscoveryAt: string | null;
  randomMiningClaim: RandomMiningClaimQuote | null;
};

export function getClaimsMarketState(): Promise<ClaimsMarketState> {
  return getUi<ClaimsMarketState>("claims-market");
}

export type ClaimsMarketPurchaseResult = {
  ok: boolean;
  message?: string;
  claim?: { id: number; key: string };
  buyerCredits?: number;
  dashboard?: DashboardState;
};

export async function purchaseClaimDeed(params: {
  siteKey: string;
}): Promise<ClaimsMarketPurchaseResult> {
  return postUi<ClaimsMarketPurchaseResult>("claims-market/purchase", {
    siteKey: params.siteKey,
  });
}

export async function purchaseRandomMiningClaim(): Promise<ClaimsMarketPurchaseResult> {
  return postUi<ClaimsMarketPurchaseResult>("claims-market/purchase-random-mining-claim", {});
}

export async function listClaimForSale(params: {
  claimId: number;
  price: number;
}): Promise<{ ok: boolean; message?: string; dashboard?: DashboardState }> {
  return postUi("claims-market/list-claim", {
    claimId: params.claimId,
    price: params.price,
  });
}

export async function purchaseListedClaim(params: {
  claimId: number;
}): Promise<{ ok: boolean; message?: string; dashboard?: DashboardState }> {
  return postUi("claims-market/purchase-listed-claim", {
    claimId: params.claimId,
  });
}

export type ClaimDetailState = {
  ok: boolean;
  message?: string;
  claim?: {
    id: number;
    key: string;
    description: string;
    isJackpot: boolean;
    allowedPurposes?: string[];
  };
  site?: MineSiteDetails;
  storyLines?: StoryLine[];
  inventoryPreview?: DashboardInventoryItem;
  isOwner?: boolean;
  isListed?: boolean;
};

export async function getClaimDetail(claimId: number): Promise<ClaimDetailState> {
  return getUi<ClaimDetailState>("claim/detail", { claimId: String(claimId) });
}

export type MineDeployResult = {
  ok: boolean;
  message?: string;
  dashboard?: DashboardState;
};

export async function mineDeploy(params: {
  packageId: number;
  claimId: number;
}): Promise<MineDeployResult> {
  return postUi<MineDeployResult>("mine/deploy", {
    packageId: params.packageId,
    claimId: params.claimId,
  });
}

export type MineUndeployResult = {
  ok: boolean;
  message?: string;
  dashboard?: DashboardState;
  returnedEquipment?: {
    rig?: { id: number; key: string };
    storage?: { id: number; key: string };
    hauler?: { id: number; key: string };
  };
};

export async function mineUndeploy(params: {
  siteId?: number;
  siteKey?: string;
}): Promise<MineUndeployResult> {
  return postUi<MineUndeployResult>("mine/undeploy", params);
}

export async function mineReactivate(params: {
  siteId: number;
  packageId?: number;
}): Promise<{ ok: boolean; message?: string; dashboard?: DashboardState }> {
  const body: Record<string, unknown> = { siteId: params.siteId };
  if (params.packageId != null) {
    body.packageId = params.packageId;
  }
  return postUi("mine/reactivate", body);
}

export async function mineRepairRig(params: {
  siteId: number;
  rigKey?: string;
  roomKey?: string;
}): Promise<{
  ok: boolean;
  message?: string;
  credits?: number;
  repair?: { totalCr: number; taxCr: number; vendorCr: number };
  play?: PlayState;
}> {
  const body: Record<string, unknown> = { siteId: params.siteId };
  if (params.rigKey) {
    body.rigKey = params.rigKey;
  }
  if (params.roomKey) {
    body.roomKey = params.roomKey;
  }
  return postUi("mine/repair-rig", body);
}

export async function listMinePropertyForClaims(params: {
  siteId: number;
  price: number;
}): Promise<{ ok: boolean; message?: string; dashboard?: DashboardState }> {
  return postUi("claims-market/list-property", {
    siteId: params.siteId,
    price: params.price,
  });
}

export async function packageListForSale(params: {
  packageId: number;
  price: number;
}): Promise<{ ok: boolean; message?: string; dashboard?: DashboardState }> {
  return postUi("package/list", params);
}

export async function dashboardAckAlert(params: {
  alertId: string;
}): Promise<{ ok: boolean; message?: string; dashboard?: DashboardState }> {
  return postUi("dashboard/ack-alert", { alertId: params.alertId });
}

export async function dashboardAckAllAlerts(): Promise<{
  ok: boolean;
  message?: string;
  cleared?: number;
  dashboard?: DashboardState;
}> {
  return postUi("dashboard/ack-all-alerts", {});
}

// ---------------------------------------------------------------------------
// Real Estate Office
// ---------------------------------------------------------------------------

export type PropertyLotRow = {
  lotKey: string;
  lotId: number;
  tier: number;
  tierLabel: string;
  zone: string;
  zoneLabel: string;
  sizeUnits: number;
  listingPriceCr: number;
  purchasable: boolean;
  sellerKey: string;
  venueId?: string;
};

export type RealEstateState = {
  venueId?: string;
  officeRoomKey?: string;
  brokerName: string;
  storyLines: StoryLine[];
  lots: PropertyLotRow[];
  nextPropertyDiscoveryAt: string | null;
};

export function getRealEstateState(venue?: string): Promise<RealEstateState> {
  return getUi<RealEstateState>("real-estate", venue ? { venue } : undefined);
}

export async function purchasePropertyDeed(params: {
  lotKey: string;
}): Promise<{ ok: boolean; message?: string; dashboard?: DashboardState }> {
  return postUi("real-estate/purchase", { lotKey: params.lotKey });
}

export type PropertyZone = "commercial" | "residential" | "industrial";

export async function purchaseRandomPropertyDeed(params: {
  zone: PropertyZone;
  venueId?: string;
}): Promise<{
  ok: boolean;
  message?: string;
  claim?: { id: number; key: string };
  dashboard?: DashboardState;
}> {
  return postUi("real-estate/purchase-random", {
    zone: params.zone,
    ...(params.venueId ? { venueId: params.venueId } : {}),
  });
}

export type PropertyLotDetail = {
  lotKey: string;
  lotId: number;
  tier: number;
  tierLabel: string;
  zone: string;
  zoneLabel: string;
  sizeUnits: number;
  listingPriceCr: number;
  purchasable: boolean;
  sellerKey: string;
  description: string;
  isClaimed: boolean;
  ownerKey: string | null;
  ownerId: number | null;
  roomKey: string | null;
  referenceListPriceCr: number;
};

export type PropertyHoldingOperation = {
  kind: string | null;
  level: number;
  nextTickAt: string | null;
  paused: boolean;
  extraSlots: number;
};

export type PropertyHoldingStructure = {
  id: number;
  key: string;
  blueprintId: string | null;
  slotWeight: number;
  upgrades: Record<string, number>;
  condition: number;
};

export type PropertyStructureBlueprintRow = {
  id: string;
  name: string;
  structureKind: string;
  slotWeight: number;
  priceCr: number;
};

export type PropertyStructureUpgradeCatalogEntry = {
  upgradeKey: string;
  maxLevel: number;
  levelCostCr: Record<string, number>;
  allowedBlueprintIds: string[] | null;
};

export type WorkshopJobQueueRow = {
  ownerId: number;
  recipeKey: string;
  runs: number;
};

export type PropertyHoldingWorkshopRow = {
  workshopId: number;
  key: string;
  blueprintId: string;
  stationKind: string;
  jobQueue: WorkshopJobQueueRow[];
  inputInventory: Record<string, number>;
  outputInventory: Record<string, number>;
};

export type ManufacturingRecipeRow = {
  id: string;
  name: string;
  stationKind: string;
};

export type ManufacturedProductRow = {
  id: string;
  name: string;
};

export type ManufacturingFeedStockRow = {
  productKey: string;
  unitsAvailable: number;
  name: string;
};

export type PropertyHoldingDetail = {
  holdingId: number;
  developmentState: string;
  zone: string;
  lotTier: number;
  sizeUnits: number;
  structureSlotsUsed: number;
  structureSlotsTotal: number;
  operation: PropertyHoldingOperation;
  ledger: { creditsAccrued: number; lastTickIso: string | null };
  place: { mode: string; rootRoomId: number | null };
  staffRoleKeys: string[];
  eventQueueLength: number;
  eventQueuePreview: Array<Record<string, unknown>>;
  structures: PropertyHoldingStructure[];
  defaultOperationKind: string | null;
  allowedOperationKinds: string[];
  buildCatalog: PropertyStructureBlueprintRow[];
  structureUpgradeCatalog: PropertyStructureUpgradeCatalogEntry[];
  nextExtraStructureSlotPriceCr: number;
  retoolFeeCr: number;
  deedTransferFeeCr: number;
  workshops?: PropertyHoldingWorkshopRow[];
  manufacturingRecipes?: ManufacturingRecipeRow[];
  manufacturedProducts?: ManufacturedProductRow[];
  manufacturingFeedStockHoldingOnly?: ManufacturingFeedStockRow[];
  manufacturingFeedStockWithRoom?: ManufacturingFeedStockRow[];
};

export type PortableProcessorCarriedRow = {
  id: number;
  key: string;
  mk: number;
};

export type PropertyClaimDetailState = {
  ok: boolean;
  message?: string;
  claim?: {
    id: number;
    key: string;
    description: string;
    lotKey: string;
    lotTier: number;
    kind: string;
  };
  lot?: PropertyLotDetail | null;
  holding?: PropertyHoldingDetail | null;
  storyLines?: StoryLine[];
  inventoryPreview?: DashboardInventoryItem;
  isOwner?: boolean;
  portableProcessorsCarried?: PortableProcessorCarriedRow[];
};

export type PropertyStartOperationResult = {
  ok: boolean;
  message?: string;
  holding?: PropertyHoldingDetail;
};

export function getPropertyClaimDetail(claimId: number): Promise<PropertyClaimDetailState> {
  return getUi<PropertyClaimDetailState>("property/detail", { claimId: String(claimId) });
}

export type PropertyProcessorDeployResult = {
  ok: boolean;
  message?: string;
  processorId?: number;
  roomKey?: string;
  play?: PlayState;
  dashboard?: DashboardState;
};

export async function propertyProcessorDeploy(params: {
  claimId: number;
  processorId: number;
}): Promise<PropertyProcessorDeployResult> {
  return postUi<PropertyProcessorDeployResult>("property/processor-deploy", {
    claimId: params.claimId,
    processorId: params.processorId,
  });
}

export async function startPropertyOperation(params: {
  claimId: number;
  kind?: string;
}): Promise<PropertyStartOperationResult> {
  return postUi<PropertyStartOperationResult>("property/start-operation", {
    claimId: params.claimId,
    ...(params.kind ? { kind: params.kind } : {}),
  });
}

export type PropertyInstallStructureResult = {
  ok: boolean;
  message?: string;
  holding?: PropertyHoldingDetail;
};

export type PropertyWorkshopQueueResult = {
  ok: boolean;
  jobQueue: WorkshopJobQueueRow[];
};

export async function propertyWorkshopQueue(params: {
  claimId: number;
  workshopId: number;
  recipeKey: string;
  runs?: number;
}): Promise<PropertyWorkshopQueueResult> {
  return postUi<PropertyWorkshopQueueResult>("property/workshop-queue", {
    claimId: params.claimId,
    workshopId: params.workshopId,
    recipeKey: params.recipeKey,
    ...(params.runs != null ? { runs: params.runs } : {}),
  });
}

export type PropertyWorkshopFeedResult = {
  ok: boolean;
  fedUnits: number;
  inputInventory: Record<string, number>;
};

export async function propertyWorkshopFeed(params: {
  claimId: number;
  workshopId: number;
  productKey: string;
  units: number;
  holdingSourcesOnly?: boolean;
}): Promise<PropertyWorkshopFeedResult> {
  return postUi<PropertyWorkshopFeedResult>("property/workshop-feed", {
    claimId: params.claimId,
    workshopId: params.workshopId,
    productKey: params.productKey,
    units: params.units,
    ...(params.holdingSourcesOnly ? { holdingSourcesOnly: true } : {}),
  });
}

export type PropertyWorkshopCollectResult = {
  ok: boolean;
  credits: number;
  units?: number;
  outputInventory: Record<string, number>;
};

export async function propertyWorkshopCollect(params: {
  claimId: number;
  workshopId: number;
  productKey?: string;
}): Promise<PropertyWorkshopCollectResult> {
  return postUi<PropertyWorkshopCollectResult>("property/workshop-collect", {
    claimId: params.claimId,
    workshopId: params.workshopId,
    ...(params.productKey ? { productKey: params.productKey } : {}),
  });
}

export async function installPropertyStructure(params: {
  claimId: number;
  blueprintId: string;
}): Promise<PropertyInstallStructureResult> {
  return postUi<PropertyInstallStructureResult>("property/install-structure", {
    claimId: params.claimId,
    blueprintId: params.blueprintId,
  });
}

export async function purchasePropertyStructureUpgrade(params: {
  claimId: number;
  structureId: number;
  upgradeKey: string;
}): Promise<PropertyInstallStructureResult> {
  return postUi<PropertyInstallStructureResult>("property/structure-upgrade", {
    claimId: params.claimId,
    structureId: params.structureId,
    upgradeKey: params.upgradeKey,
  });
}

export async function purchasePropertyExtraSlot(params: {
  claimId: number;
}): Promise<PropertyInstallStructureResult> {
  return postUi<PropertyInstallStructureResult>("property/purchase-extra-slot", {
    claimId: params.claimId,
  });
}

export type PropertyOperationPauseResult = {
  ok: boolean;
  message?: string;
  holding?: PropertyHoldingDetail;
};

export async function setPropertyOperationPaused(params: {
  claimId: number;
  paused: boolean;
}): Promise<PropertyOperationPauseResult> {
  return postUi<PropertyOperationPauseResult>("property/operation-pause", {
    claimId: params.claimId,
    paused: params.paused,
  });
}

export type PropertyOperationRetoolResult = {
  ok: boolean;
  message?: string;
  holding?: PropertyHoldingDetail;
};

export async function retoolPropertyOperation(params: {
  claimId: number;
  kind: string;
}): Promise<PropertyOperationRetoolResult> {
  return postUi<PropertyOperationRetoolResult>("property/operation-retool", {
    claimId: params.claimId,
    kind: params.kind,
  });
}

export type PropertyDeedListingRow = {
  claimId: number;
  key: string;
  lotKey: string;
  kind: string;
  price: number;
  sellerKey: string;
};

export type PropertyDeedListingsState = {
  ok: boolean;
  listings: PropertyDeedListingRow[];
};

export function getPropertyDeedListings(): Promise<PropertyDeedListingsState> {
  return getUi<PropertyDeedListingsState>("property/deed-listings");
}

export type PropertyDeedListResult = {
  ok: boolean;
  message?: string;
  dashboard?: DashboardState;
};

export async function listPropertyDeedForSale(params: {
  claimId: number;
  price: number;
}): Promise<PropertyDeedListResult> {
  return postUi<PropertyDeedListResult>("property/deed-list", {
    claimId: params.claimId,
    price: params.price,
  });
}

export type PropertyDeedBuyResult = {
  ok: boolean;
  message?: string;
  dashboard?: DashboardState;
};

export async function buyListedPropertyDeed(params: {
  claimId: number;
}): Promise<PropertyDeedBuyResult> {
  return postUi<PropertyDeedBuyResult>("property/deed-buy", {
    claimId: params.claimId,
  });
}

export type MissionAcceptResult = {
  ok: boolean;
  code?: string;
  message?: string;
  mission?: MissionActive;
  dashboard?: DashboardState;
};

export type MissionChooseResult = {
  ok: boolean;
  code?: string;
  message?: string;
  mission?: MissionActive;
  dashboard?: DashboardState;
};

export type MissionDeclineResult = {
  ok: boolean;
  code?: string;
  message?: string;
  dashboard?: DashboardState;
};

export async function acceptMission(params: {
  opportunityId: string;
}): Promise<MissionAcceptResult> {
  return postUi<MissionAcceptResult>("missions/accept", {
    opportunityId: params.opportunityId,
  });
}

export async function chooseMission(params: {
  missionId: string;
  choiceId: string;
}): Promise<MissionChooseResult> {
  return postUi<MissionChooseResult>("missions/choose", params);
}

export async function declineMission(params: {
  opportunityId: string;
}): Promise<MissionDeclineResult> {
  return postUi<MissionDeclineResult>("missions/decline", {
    opportunityId: params.opportunityId,
  });
}

export async function claimChallengeReward(params: {
  challengeId: string;
  windowKey: string;
}): Promise<ChallengeClaimResult> {
  return postUi<ChallengeClaimResult>("challenges/claim", {
    challengeId: params.challengeId,
    windowKey: params.windowKey,
  });
}

export async function claimChallengeRewardsForCadence(params: {
  cadence: string;
}): Promise<ChallengeClaimResult> {
  return postUi<ChallengeClaimResult>("challenges/claim-cadence", {
    cadence: params.cadence,
  });
}

export type PlayCommandResult = {
  ok: boolean;
  code?: string;
  message?: string;
  dashboard?: DashboardState;
  play?: PlayState;
};

export async function playTravel(params: { destination: string }): Promise<PlayCommandResult> {
  return postUi<PlayCommandResult>("play/travel", { destination: params.destination });
}

export async function playInteract(params: {
  interactionKey: string;
  payload?: Record<string, unknown>;
}): Promise<PlayCommandResult> {
  return postUi<PlayCommandResult>("play/interact", {
    interactionKey: params.interactionKey,
    payload: params.payload ?? {},
  });
}
