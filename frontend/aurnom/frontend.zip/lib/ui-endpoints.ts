/** Browser-relative prefix; Next proxies to Evennia via `app/api/ui/[...path]/route.ts`. */
export const UI_PREFIX = "/api/ui";
