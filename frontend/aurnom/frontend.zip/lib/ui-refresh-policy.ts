/**
 * Default client polling intervals (ms). Tune for UI freshness vs Evennia/proxy load.
 * Optional server overrides: `ControlSurfaceState.clientPollHints` (same keys).
 */
export const UI_REFRESH_MS = {
  controlSurface: 15_000,
  postDeadlinePoll: 15_000,
  marketSnapshot: 30_000,
  worldGraph: 45_000,
  msgStream: 3_000,
} as const;

export type UiRefreshKey = keyof typeof UI_REFRESH_MS;

/** Server may send the same keys (milliseconds). */
export type ClientPollHints = Partial<Record<UiRefreshKey, number>>;

export function isUiPollPaused(): boolean {
  return typeof document !== "undefined" && document.visibilityState === "hidden";
}

export function intervalMs(key: UiRefreshKey, hints?: ClientPollHints | null): number {
  const v = hints?.[key];
  if (typeof v === "number" && Number.isFinite(v) && v >= 1_000) {
    return Math.floor(v);
  }
  return UI_REFRESH_MS[key];
}
