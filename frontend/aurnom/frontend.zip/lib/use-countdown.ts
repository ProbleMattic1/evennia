"use client";

import { useEffect, useRef, useState } from "react";

/**
 * Live countdown to targetIso.
 *
 * When the target is reached (or is already past on mount), onExpired is called
 * once. If the caller's reload returns the same past timestamp, we keep retrying
 * every RETRY_MS until a future timestamp arrives.
 */
const RETRY_MS = 5_000; // poll every 5 s while waiting for backend to catch up

export function useCountdown(
  targetIso: string | null,
  onExpired?: () => void
): string | null {
  const [label, setLabel] = useState<string | null>(null);
  const onExpiredRef = useRef(onExpired);

  useEffect(() => {
    onExpiredRef.current = onExpired;
  }, [onExpired]);

  useEffect(() => {
    /* eslint-disable react-hooks/set-state-in-effect -- timer-driven label updates */
    if (!targetIso) {
      setLabel(null);
      return;
    }

    let wasPositive = false;
    let expiredFired = false;
    let retryId: ReturnType<typeof setInterval> | null = null;

    function stopRetry() {
      if (retryId !== null) {
        clearInterval(retryId);
        retryId = null;
      }
    }

    function fireExpired() {
      if (!expiredFired) {
        expiredFired = true;
        onExpiredRef.current?.();
      }
      // Keep retrying on a short interval until the parent gives us a new
      // future targetIso (which will remount this effect with a new value).
      if (retryId === null) {
        retryId = setInterval(() => {
          onExpiredRef.current?.();
        }, RETRY_MS);
      }
    }

    function compute() {
      const diff = Math.max(
        0,
        Math.floor((new Date(targetIso!).getTime() - Date.now()) / 1000)
      );

      if (diff > 0) {
        wasPositive = true;
        stopRetry(); // target is in the future — cancel retry loop
        const h = Math.floor(diff / 3600);
        const m = Math.floor((diff % 3600) / 60);
        const s = diff % 60;
        setLabel(
          h > 0
            ? `${h}h ${String(m).padStart(2, "0")}m ${String(s).padStart(2, "0")}s`
            : `${m}m ${String(s).padStart(2, "0")}s`
        );
        return;
      }

      setLabel("now");
      if (wasPositive || !expiredFired) {
        wasPositive = false;
        fireExpired();
      }
    }

    compute();
    const tickId = setInterval(compute, 1000);

    return () => {
      clearInterval(tickId);
      stopRetry();
    };
    /* eslint-enable react-hooks/set-state-in-effect */
  }, [targetIso]);

  return label;
}
