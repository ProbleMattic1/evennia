"use client";

import { useEffect, useState } from "react";

const PREFIX = "aurnom:dashboard-panel:";

/** Session-backed open state; matches dashboard `Panel` expand/collapse behavior. */
export function useDashboardPanelOpen(panelKey: string, defaultOpen = true) {
  const storageKey = `${PREFIX}${panelKey}`;
  const [open, setOpen] = useState(() => {
    if (typeof window === "undefined") return defaultOpen;
    try {
      const raw = window.sessionStorage.getItem(storageKey);
      return raw == null ? defaultOpen : raw === "1";
    } catch {
      return defaultOpen;
    }
  });

  useEffect(() => {
    try {
      window.sessionStorage.setItem(storageKey, open ? "1" : "0");
    } catch {
      // ignore storage errors and keep UI functional
    }
  }, [open, storageKey]);

  return [open, setOpen] as const;
}
