"use client";

import { useCallback, useState } from "react";

import type { MarketCommodity } from "@/lib/ui-api";

export type MarketSnapshot = { t: number; commodities: MarketCommodity[] };

const MAX = 120;

export function useMarketHistory() {
  const [history, setHistory] = useState<MarketSnapshot[]>([]);
  const push = useCallback((commodities: MarketCommodity[]) => {
    const row: MarketSnapshot = { t: Date.now(), commodities };
    setHistory((h) => {
      const n = [...h, row];
      return n.length > MAX ? n.slice(-MAX) : n;
    });
  }, []);
  const clear = useCallback(() => setHistory([]), []);
  return { history, push, clear };
}

/** Series for one resource key: sell price over time. */
export function seriesForKey(history: MarketSnapshot[], key: string): { t: number; sell: number }[] {
  const out: { t: number; sell: number }[] = [];
  for (const snap of history) {
    const c = snap.commodities.find((x) => x.key === key);
    if (c) out.push({ t: snap.t, sell: c.sellPriceCrPerTon });
  }
  return out;
}
