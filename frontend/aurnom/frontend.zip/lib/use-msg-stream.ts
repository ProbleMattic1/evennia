"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { getMsgStream, type MsgStreamEntry } from "./ui-api";
import { UI_REFRESH_MS } from "./ui-refresh-policy";
const MAX_DISPLAY_MESSAGES = 200;

export function useMsgStream() {
  const [messages, setMessages] = useState<MsgStreamEntry[]>([]);
  const sinceRef = useRef(0);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  /** Serializes polls so `since` always advances before the next fetch uses it. */
  const pollLockRef = useRef<Promise<void>>(Promise.resolve());

  const poll = useCallback(async () => {
    pollLockRef.current = pollLockRef.current.then(async () => {
      try {
        const since = sinceRef.current;
        const res = await getMsgStream(since);
        if (!res.ok || res.messages.length === 0) {
          return;
        }
        // Server guarantees strictly increasing seq per character; advance cursor
        // before merge so a overlapping Strict Mode / retry cannot reuse stale `since`.
        sinceRef.current = res.seq;
        setMessages((prev) => {
          const maxPrev =
            prev.length === 0
              ? since
              : Math.max(since, ...prev.map((m) => m.seq));
          const fresh = res.messages.filter((m) => m.seq > maxPrev);
          if (fresh.length === 0) {
            return prev;
          }
          const next = [...prev, ...fresh];
          return next.length > MAX_DISPLAY_MESSAGES
            ? next.slice(-MAX_DISPLAY_MESSAGES)
            : next;
        });
      } catch {
        // Transient failure: next tick retries with same `since` (correct for Evennia semantics).
      }
    });
    await pollLockRef.current;
  }, []);

  useEffect(() => {
    void poll();
    timerRef.current = setInterval(() => {
      void poll();
    }, UI_REFRESH_MS.msgStream);
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [poll]);

  const clear = useCallback(() => {
    sinceRef.current = 0;
    setMessages([]);
  }, []);

  return { messages, clear };
}
