import { useEffect, useState } from "react";

/**
 * Moves display toward target integer (CR) for odometer feel; cheap between rAF ticks.
 * If |target − v| exceeds snapIfDeltaExceeds, jumps immediately (e.g. large persisted totals).
 */
export function useOdometerInt(target: number, maxStep = 12, snapIfDeltaExceeds = Number.POSITIVE_INFINITY): number {
  const [v, setV] = useState(0);

  useEffect(() => {
    if (Math.abs(target - v) > snapIfDeltaExceeds) {
      setV(target);
      return;
    }
    if (v === target) return;
    const id = requestAnimationFrame(() => {
      setV((prev) => {
        const d = target - prev;
        if (d === 0) return prev;
        const step = Math.sign(d) * Math.min(Math.abs(d), maxStep);
        return prev + step;
      });
    });
    return () => cancelAnimationFrame(id);
  }, [v, target, maxStep, snapIfDeltaExceeds]);

  return v;
}
