"use client";

import { useEffect } from "react";

import { isUiPollPaused } from "@/lib/ui-refresh-policy";

/**
 * After a server ISO instant is in the past, poll `reload` on a fixed interval.
 * Respects tab visibility to reduce idle load on Evennia.
 */
export function useReloadAfterIso(
  iso: string | null | undefined,
  reload: () => void,
  intervalMs: number,
): void {
  useEffect(() => {
    if (!iso) return;
    if (new Date(iso).getTime() > Date.now()) return;
    const id = setInterval(() => {
      if (!isUiPollPaused()) reload();
    }, intervalMs);
    return () => clearInterval(id);
  }, [iso, reload, intervalMs]);
}
