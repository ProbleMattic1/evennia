"use client";

import { useEffect, useState } from "react";

import { buildResourceNameLookup } from "@/lib/resource-display";
import { getResources } from "@/lib/ui-api";

/** Loads `/ui/resources` once per mount for display names (composition, inventory, etc.). */
export function useResourceNameLookup(): Map<string, string> {
  const [lookup, setLookup] = useState<Map<string, string>>(() => new Map());

  useEffect(() => {
    let cancelled = false;
    getResources()
      .then((s) => {
        if (!cancelled) {
          setLookup(buildResourceNameLookup(s.resources));
        }
      })
      .catch(() => {
        if (!cancelled) {
          setLookup(new Map());
        }
      });
    return () => {
      cancelled = true;
    };
  }, []);

  return lookup;
}
