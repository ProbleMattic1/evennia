"use client";

import { useEffect, useLayoutEffect, useRef, useState } from "react";

/**
 * Smooth "server" clock for UI: advances between control-surface polls.
 * Re-anchors when `serverTimeIso` changes (each successful fetch).
 * Time updates only inside effects / rAF — avoids impure calls during render.
 */
export function useServerAnchoredTimeMs(serverTimeIso: string | undefined): number {
  const anchorRef = useRef<{ serverMs: number; perf: number } | null>(null);
  const [nowMs, setNowMs] = useState(0);

  useLayoutEffect(() => {
    if (!serverTimeIso) {
      anchorRef.current = null;
      queueMicrotask(() => setNowMs(Date.now()));
      return;
    }
    const serverMs = Date.parse(serverTimeIso);
    if (!Number.isFinite(serverMs)) {
      return;
    }
    anchorRef.current = { serverMs, perf: performance.now() };
    queueMicrotask(() => setNowMs(serverMs));
  }, [serverTimeIso]);

  useEffect(() => {
    let id = 0;
    const loop = () => {
      const a = anchorRef.current;
      setNowMs(a ? a.serverMs + (performance.now() - a.perf) : Date.now());
      id = requestAnimationFrame(loop);
    };
    id = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(id);
  }, []);

  return nowMs;
}
