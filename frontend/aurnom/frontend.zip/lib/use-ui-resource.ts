"use client";

import { useCallback, useEffect, useState } from "react";

export function useUiResource<T>(loader: () => Promise<T>): {
  data: T | null;
  error: string | null;
  loading: boolean;
  reload: () => void;
} {
  const [data, setData] = useState<T | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [tick, setTick] = useState(0);

  const reload = useCallback(() => setTick((t) => t + 1), []);

  useEffect(() => {
    let cancelled = false;
    // Only block the UI on the first fetch. Background reloads keep the current view
    // mounted so hooks (e.g. Countdown onExpired → reload) do not remount and re-fire.
    if (tick === 0) {
      /* eslint-disable react-hooks/set-state-in-effect -- intentional: reset loading before each initial fetch */
      setLoading(true);
      setError(null);
      /* eslint-enable react-hooks/set-state-in-effect */
    }

    loader()
      .then((result) => {
        if (!cancelled) {
          setData(result);
          setLoading(false);
        }
      })
      .catch((err: unknown) => {
        if (!cancelled) {
          setError(err instanceof Error ? err.message : "Request failed");
          setData(null);
          setLoading(false);
        }
      });

    return () => {
      cancelled = true;
    };
  }, [loader, tick]);

  return { data, error, loading, reload };
}
