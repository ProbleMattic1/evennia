"""
Economy Engine v1 for an Evennia-based RPG.

Design goals:
- Keep the canonical economy state in one global Script.
- Support base prices, category/domain modifiers, faction modifiers,
  and location/shop modifiers.
- Work cleanly with imported vehicle objects that already store their
  economy data in obj.db.economy and classification data in obj.db.specs.
- Provide a small API that can be called from commands, shops, scripts,
  and batchcode.

Suggested bootstrap:
    from evennia import create_script
    create_script("typeclasses.economy.EconomyEngine")

Suggested lookup:
    from typeclasses.economy import get_economy
    econ = get_economy()
    price = econ.get_final_price(vehicle, buyer=caller, location=caller.location)
"""

from copy import deepcopy
from evennia import DefaultScript, GLOBAL_SCRIPTS, search_script


DEFAULT_ECONOMY_STATE = {
    "version": 1,
    "currency": "credits",
    "rounding_mode": "nearest_int",
    "global_modifier": 1.0,
    "buy_rate": 1.00,
    "sell_rate": 0.45,
    "black_market_buy_rate": 1.35,
    "black_market_sell_rate": 0.70,
    "scarcity_floor": 0.60,
    "scarcity_ceiling": 1.80,
    "default_tax_rate": 0.00,
    "category_modifiers": {
        # values are multiplicative
        "vehicle": 1.00,
        "surface_vehicle": 1.00,
        "watercraft": 1.05,
        "aircraft": 1.12,
        "spacecraft": 1.30,
    },
    "domain_modifiers": {
        "surface": 1.00,
        "water": 1.04,
        "air": 1.10,
        "space": 1.28,
    },
    "rarity_modifiers": {
        "common": 1.00,
        "uncommon": 1.10,
        "rare": 1.30,
        "very-rare": 1.55,
        "legendary": 2.10,
    },
    "legal_class_modifiers": {
        "open": 1.00,
        "licensed": 1.08,
        "restricted": 1.25,
        "military": 1.50,
        "prohibited": 2.10,
    },
    "faction_modifiers": {
        # seller/buyer friendly faction examples; override in game data
        "civilian": 1.00,
        "corporate": 1.08,
        "government": 1.05,
        "black-market": 1.40,
        "pirate": 1.18,
    },
    "standing_bands": {
        # standing score thresholds -> discount/premium modifiers
        "ally": 0.90,
        "friendly": 0.96,
        "neutral": 1.00,
        "unfriendly": 1.10,
        "hostile": 1.30,
    },
    "regional_modifiers": {},
    "location_modifiers": {},
    "item_overrides": {},
}


class EconomyEngine(DefaultScript):
    """
    Global economy controller.

    Persistent state lives on `self.db.state`.
    Volatile caches can live on `self.ndb` if needed later.
    """

    def at_script_creation(self):
        self.key = "global_economy"
        self.desc = "Global economy controller for market pricing."
        self.interval = 0
        self.persistent = True
        self.start_delay = False
        self.db.state = deepcopy(DEFAULT_ECONOMY_STATE)
        self.db.price_history = {}
        self.db.last_tick = None

    # -----------------------------
    # Basic state helpers
    # -----------------------------

    @property
    def state(self):
        return self.db.state or deepcopy(DEFAULT_ECONOMY_STATE)

    def save_state(self, new_state):
        self.db.state = new_state
        return self.db.state

    def reset_defaults(self):
        self.db.state = deepcopy(DEFAULT_ECONOMY_STATE)
        return self.db.state

    def get_modifier_table(self, table_name):
        return (self.state or {}).get(table_name, {}) or {}

    def set_modifier(self, table_name, key, value):
        state = deepcopy(self.state)
        state.setdefault(table_name, {})[str(key)] = float(value)
        self.save_state(state)
        return state[table_name][str(key)]

    def remove_modifier(self, table_name, key):
        state = deepcopy(self.state)
        table = state.setdefault(table_name, {})
        table.pop(str(key), None)
        self.save_state(state)

    def set_global_modifier(self, value):
        state = deepcopy(self.state)
        state["global_modifier"] = float(value)
        self.save_state(state)
        return state["global_modifier"]

    # -----------------------------
    # Price extraction helpers
    # -----------------------------

    def get_base_price(self, item):
        """
        Determine an item's canonical base price.

        Priority:
        1. obj.db.economy['total_price_cr']
        2. obj.db.economy['base_price_cr']
        3. obj.db.price
        4. obj.db.base_price
        """
        if not item:
            return 0

        economy = getattr(item.db, "economy", None) or {}
        for key in ("total_price_cr", "base_price_cr"):
            value = economy.get(key)
            if isinstance(value, (int, float)):
                return value

        for attr in ("price", "base_price"):
            value = getattr(item.db, attr, None)
            if isinstance(value, (int, float)):
                return value

        return 0

    def get_item_key(self, item):
        catalog = getattr(item.db, "catalog", None) or {}
        return catalog.get("vehicle_id") or item.key

    def get_item_category(self, item):
        return getattr(item.db, "vehicle_kind", None) or "vehicle"

    def get_item_domain(self, item):
        specs = getattr(item.db, "specs", None) or {}
        return specs.get("domain_slug") or specs.get("domain")

    def get_item_rarity(self, item):
        economy = getattr(item.db, "economy", None) or {}
        return economy.get("rarity_slug") or economy.get("rarity")

    def get_item_legal_class(self, item):
        economy = getattr(item.db, "economy", None) or {}
        return economy.get("legal_class_slug") or economy.get("legal_class")

    def get_item_faction(self, item):
        catalog = getattr(item.db, "catalog", None) or {}
        lore = getattr(item.db, "lore", None) or {}
        return (
            catalog.get("primary_faction_slug")
            or lore.get("primary_faction_slug")
            or lore.get("primary_faction")
        )

    # -----------------------------
    # Context resolution helpers
    # -----------------------------

    def get_location_modifier(self, location=None):
        if not location:
            return 1.0

        # direct object override wins
        explicit = getattr(location.db, "price_modifier", None)
        if isinstance(explicit, (int, float)):
            return float(explicit)

        # then named location override by key/id/tag
        table = self.get_modifier_table("location_modifiers")
        candidates = [str(location.key)]
        if getattr(location.db, "location_id", None):
            candidates.append(str(location.db.location_id))
        for cand in candidates:
            if cand in table:
                return float(table[cand])
        return 1.0

    def get_region_modifier(self, location=None):
        if not location:
            return 1.0

        region = getattr(location.db, "region", None) or getattr(location.db, "market_region", None)
        if not region:
            return 1.0
        return float(self.get_modifier_table("regional_modifiers").get(str(region), 1.0))

    def get_faction_modifier(self, faction_key=None):
        if not faction_key:
            return 1.0
        return float(self.get_modifier_table("faction_modifiers").get(str(faction_key), 1.0))

    def get_standing_modifier(self, standing="neutral"):
        return float(self.get_modifier_table("standing_bands").get(str(standing), 1.0))

    def get_tax_rate(self, location=None):
        explicit = getattr(getattr(location, "db", None), "tax_rate", None) if location else None
        if isinstance(explicit, (int, float)):
            return float(explicit)
        return float(self.state.get("default_tax_rate", 0.0))

    def get_scarcity_modifier(self, item=None, location=None):
        """
        Scarcity can come from location state or item state.
        Expected values are multiplicative, such as 0.85 or 1.25.
        """
        scarcity = None

        if location:
            scarcity = getattr(location.db, "scarcity_modifier", None)
        if scarcity is None and item:
            scarcity = getattr(item.db, "scarcity_modifier", None)
        if scarcity is None:
            scarcity = 1.0

        try:
            scarcity = float(scarcity)
        except (TypeError, ValueError):
            scarcity = 1.0

        floor = float(self.state.get("scarcity_floor", 0.60))
        ceil = float(self.state.get("scarcity_ceiling", 1.80))
        return max(floor, min(ceil, scarcity))

    # -----------------------------
    # Price computation
    # -----------------------------

    def get_item_override(self, item):
        item_key = self.get_item_key(item)
        return self.get_modifier_table("item_overrides").get(str(item_key))

    def get_buy_sell_rate(self, market_type="normal", transaction_type="buy"):
        if market_type == "black_market":
            return float(self.state.get(
                "black_market_buy_rate" if transaction_type == "buy" else "black_market_sell_rate", 1.0
            ))
        return float(self.state.get("buy_rate" if transaction_type == "buy" else "sell_rate", 1.0))

    def get_final_price(self, item, buyer=None, seller=None, location=None,
                        market_type="normal", transaction_type="buy", standing="neutral"):
        base_price = float(self.get_base_price(item) or 0)
        if base_price <= 0:
            return 0

        override = self.get_item_override(item)
        if isinstance(override, (int, float)):
            base_price = float(override)

        global_mod = float(self.state.get("global_modifier", 1.0))
        category_mod = float(self.get_modifier_table("category_modifiers").get(self.get_item_category(item), 1.0))
        domain_mod = float(self.get_modifier_table("domain_modifiers").get(self.get_item_domain(item), 1.0))
        rarity_mod = float(self.get_modifier_table("rarity_modifiers").get(self.get_item_rarity(item), 1.0))
        legal_mod = float(self.get_modifier_table("legal_class_modifiers").get(self.get_item_legal_class(item), 1.0))
        faction_mod = float(self.get_faction_modifier(self.get_item_faction(item)))
        region_mod = float(self.get_region_modifier(location))
        location_mod = float(self.get_location_modifier(location))
        scarcity_mod = float(self.get_scarcity_modifier(item=item, location=location))
        standing_mod = float(self.get_standing_modifier(standing))
        buy_sell_mod = float(self.get_buy_sell_rate(market_type=market_type, transaction_type=transaction_type))

        subtotal = (
            base_price
            * global_mod
            * category_mod
            * domain_mod
            * rarity_mod
            * legal_mod
            * faction_mod
            * region_mod
            * location_mod
            * scarcity_mod
            * standing_mod
            * buy_sell_mod
        )

        tax_rate = self.get_tax_rate(location=location)
        if transaction_type == "buy" and tax_rate:
            subtotal *= (1.0 + tax_rate)

        rounding_mode = self.state.get("rounding_mode", "nearest_int")
        if rounding_mode == "floor":
            final = int(subtotal)
        elif rounding_mode == "ceil":
            final = int(subtotal) if subtotal == int(subtotal) else int(subtotal) + 1
        else:
            final = int(round(subtotal))
        return max(final, 0)

    def get_price_breakdown(self, item, buyer=None, seller=None, location=None,
                            market_type="normal", transaction_type="buy", standing="neutral"):
        base_price = float(self.get_base_price(item) or 0)
        return {
            "base_price": base_price,
            "global_modifier": float(self.state.get("global_modifier", 1.0)),
            "category_modifier": float(self.get_modifier_table("category_modifiers").get(self.get_item_category(item), 1.0)),
            "domain_modifier": float(self.get_modifier_table("domain_modifiers").get(self.get_item_domain(item), 1.0)),
            "rarity_modifier": float(self.get_modifier_table("rarity_modifiers").get(self.get_item_rarity(item), 1.0)),
            "legal_class_modifier": float(self.get_modifier_table("legal_class_modifiers").get(self.get_item_legal_class(item), 1.0)),
            "faction_modifier": float(self.get_faction_modifier(self.get_item_faction(item))),
            "regional_modifier": float(self.get_region_modifier(location)),
            "location_modifier": float(self.get_location_modifier(location)),
            "scarcity_modifier": float(self.get_scarcity_modifier(item=item, location=location)),
            "standing_modifier": float(self.get_standing_modifier(standing)),
            "buy_sell_modifier": float(self.get_buy_sell_rate(market_type=market_type, transaction_type=transaction_type)),
            "tax_rate": float(self.get_tax_rate(location=location)),
            "market_type": market_type,
            "transaction_type": transaction_type,
            "standing": standing,
            "final_price": self.get_final_price(
                item,
                buyer=buyer,
                seller=seller,
                location=location,
                market_type=market_type,
                transaction_type=transaction_type,
                standing=standing,
            ),
        }

    # -----------------------------
    # Optional simple market tick
    # -----------------------------

    def apply_market_shift(self, scope="global", key=None, pct_change=0.0):
        """
        A simple manual tuning helper for v1.
        pct_change is additive against an existing multiplier:
            current 1.00 + pct_change 0.10 => 1.10
        """
        if scope == "global":
            current = float(self.state.get("global_modifier", 1.0))
            return self.set_global_modifier(max(0.01, current + float(pct_change)))

        scope_map = {
            "region": "regional_modifiers",
            "location": "location_modifiers",
            "faction": "faction_modifiers",
            "item": "item_overrides",
        }
        table_name = scope_map.get(scope)
        if not table_name or key is None:
            raise ValueError("Unsupported scope or missing key.")

        table = self.get_modifier_table(table_name)
        current = float(table.get(str(key), 1.0))
        return self.set_modifier(table_name, key, max(0.01, current + float(pct_change)))


# -----------------------------
# Module-level convenience helpers
# -----------------------------

def get_economy(create_missing=True):
    """
    Find the global economy script.
    """
    try:
        econ = GLOBAL_SCRIPTS.global_economy
        if econ:
            return econ
    except Exception:
        pass

    found = search_script("global_economy")
    if found:
        return found[0]

    if create_missing:
        from evennia import create_script
        return create_script("typeclasses.economy.EconomyEngine")
    return None


def get_price(item, location=None, market_type="normal", transaction_type="buy", standing="neutral"):
    econ = get_economy(create_missing=True)
    return econ.get_final_price(
        item,
        location=location,
        market_type=market_type,
        transaction_type=transaction_type,
        standing=standing,
    )
