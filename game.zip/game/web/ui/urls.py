from django.urls import path
from django.views.generic import RedirectView

from . import views
from . import world_graph
from .control_surface import control_surface_state
from .economy_world import economy_world_state

urlpatterns = [
    path("active-character", views.web_set_active_character, name="ui-active-character"),
    path("active-character/clear", views.web_clear_active_character, name="ui-active-character-clear"),
    path("control-surface", control_surface_state, name="ui-control-surface"),
    path("economy-world", economy_world_state, name="ui-economy-world"),
    path("play", views.play_state, name="ui-play"),
    path("play/travel", views.play_travel, name="ui-play-travel"),
    path("play/interact", views.play_interact, name="ui-play-interact"),
    path("msg-stream", views.msg_stream, name="ui-msg-stream"),
    path("nav", views.nav_state, name="ui-nav"),
    path("world-graph", world_graph.world_graph_state, name="ui-world-graph"),
    path("dashboard", views.dashboard_state, name="ui-dashboard"),
    path("dashboard/ack-alert", views.dashboard_ack_alert, name="ui-dashboard-ack-alert"),
    # Accept with or without trailing slash (proxies/clients vary; POST does not follow APPEND_SLASH redirects).
    path("dashboard/ack-all-alerts", views.dashboard_ack_all_alerts, name="ui-dashboard-ack-all-alerts"),
    path("dashboard/ack-all-alerts/", views.dashboard_ack_all_alerts),
    path("bank", views.bank_state, name="ui-bank"),
    path("real-estate", views.real_estate_state, name="ui-real-estate"),
    path("real-estate/purchase", views.real_estate_purchase, name="ui-real-estate-purchase"),
    path(
        "real-estate/purchase-random",
        views.real_estate_purchase_random,
        name="ui-real-estate-purchase-random",
    ),
    path("processing", views.processing_state, name="ui-processing"),
    path(
        "shipyard",
        RedirectView.as_view(
            url="shop?room=Meridian%20Civil%20Shipyard",
            permanent=False,
        ),
        name="ui-shipyard-redirect",
    ),
    path("shop", views.shop_state, name="ui-shop"),
    path("shop/inspect", views.shop_inspect, name="ui-shop-inspect"),
    path("shop/buy", views.shop_buy, name="ui-shop-buy"),
    path("market", views.market_state, name="ui-market"),
    path("claims-market", views.claims_market_state, name="ui-claims-market"),
    path("claims-market/purchase", views.claims_market_purchase, name="ui-claims-market-purchase"),
    path(
        "claims-market/purchase-random-mining-claim",
        views.claims_market_purchase_random_mining_claim,
        name="ui-claims-market-purchase-random-mining-claim",
    ),
    path("claims-market/list-property", views.claims_market_list_property, name="ui-claims-market-list-property"),
    path("claims-market/list-claim", views.claims_market_list_claim, name="ui-claims-market-list-claim"),
    path(
        "claims-market/purchase-listed-claim",
        views.claims_market_purchase_listed_claim,
        name="ui-claims-market-purchase-listed-claim",
    ),
    path("claim/detail", views.claim_detail_state, name="ui-claim-detail"),
    path("property/detail", views.property_claim_detail_state, name="ui-property-detail"),
    path(
        "property/start-operation",
        views.property_start_operation,
        name="ui-property-start-operation",
    ),
    path(
        "property/install-structure",
        views.property_install_structure,
        name="ui-property-install-structure",
    ),
    path(
        "property/processor-deploy",
        views.property_processor_deploy,
        name="ui-property-processor-deploy",
    ),
    path(
        "property/workshop-queue",
        views.property_workshop_queue,
        name="ui-property-workshop-queue",
    ),
    path(
        "property/workshop-feed",
        views.property_workshop_feed,
        name="ui-property-workshop-feed",
    ),
    path(
        "property/workshop-collect",
        views.property_workshop_collect,
        name="ui-property-workshop-collect",
    ),
    path(
        "property/structure-upgrade",
        views.property_structure_upgrade,
        name="ui-property-structure-upgrade",
    ),
    path(
        "property/purchase-extra-slot",
        views.property_purchase_extra_slot,
        name="ui-property-purchase-extra-slot",
    ),
    path(
        "property/operation-pause",
        views.property_operation_pause,
        name="ui-property-operation-pause",
    ),
    path(
        "property/operation-retool",
        views.property_operation_retool,
        name="ui-property-operation-retool",
    ),
    path(
        "property/resolve-incident",
        views.property_resolve_incident,
        name="ui-property-resolve-incident",
    ),
    path(
        "property/deed-listings",
        views.property_deed_listings_state,
        name="ui-property-deed-listings",
    ),
    path("property/deed-list", views.property_deed_list, name="ui-property-deed-list"),
    path("property/deed-buy", views.property_deed_buy, name="ui-property-deed-buy"),
    path("property/ops-health", views.property_ops_health, name="ui-property-ops-health"),
    path(
        "manufacturing/ops-health",
        views.manufacturing_ops_health,
        name="ui-manufacturing-ops-health",
    ),
    path("resources", views.resources_state, name="ui-resources"),
    path("mine/claims", views.mine_claims, name="ui-mine-claims"),
    path("mine/deploy", views.mine_deploy, name="ui-mine-deploy"),
    path("mine/undeploy", views.mine_undeploy, name="ui-mine-undeploy"),
    path("mine/reactivate", views.mine_reactivate, name="ui-mine-reactivate"),
    path("mine/repair-rig", views.mine_repair_rig, name="ui-mine-repair-rig"),
    path("package/list", views.package_list_for_sale, name="ui-package-list"),
    path("package/listings", views.package_listings_state, name="ui-package-listings"),
    path("package/buy", views.package_buy_listed, name="ui-package-buy"),
    path("missions/accept", views.missions_accept, name="ui-missions-accept"),
    path("missions/choose", views.missions_choose, name="ui-missions-choose"),
    path("missions/decline", views.missions_decline, name="ui-missions-decline"),
    path("debug/msg-buffer", views.debug_msg_buffer, name="ui-debug-msg-buffer"),
]
