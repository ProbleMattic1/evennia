# World scripts: bootstrap, batchcode, etc.
