#
# Batchcode bootstrap for Economy Engine v1
#
# Usage:
#   > batchcode world.scripts.bootstrap_economy
#   > batchcode/debug world.scripts.bootstrap_economy
#
# This ensures a global_economy script exists and seeds example modifiers.
#

#HEADER
from evennia import create_script, search_script

SCRIPT_PATH = "typeclasses.economy.EconomyEngine"
SCRIPT_KEY = "global_economy"
DRY_RUN = bool(DEBUG)


def caller_msg(text):
    if caller:
        caller.msg(text)


def get_existing():
    found = search_script(SCRIPT_KEY)
    return found[0] if found else None


#CODE
existing = get_existing()
if existing:
    caller_msg(f"|yEconomy script already exists:|n {existing.key}")
    econ = existing
elif DRY_RUN:
    caller_msg(f"[DRY RUN] Would create script {SCRIPT_KEY} from {SCRIPT_PATH}")
    econ = None
else:
    econ = create_script(SCRIPT_PATH, key=SCRIPT_KEY)
    caller_msg(f"|gCreated economy script:|n {econ.key}")

if econ and not DRY_RUN:
    # Example starter tuning only. Safe to delete/replace later.
    econ.set_modifier("regional_modifiers", "core-worlds", 1.08)
    econ.set_modifier("regional_modifiers", "frontier", 0.94)
    econ.set_modifier("location_modifiers", "black-market-exchange", 1.40)
    econ.set_modifier("faction_modifiers", "allied-traders-guild", 0.95)
    caller_msg("|gSeeded starter regional/location/faction modifiers.|n")
